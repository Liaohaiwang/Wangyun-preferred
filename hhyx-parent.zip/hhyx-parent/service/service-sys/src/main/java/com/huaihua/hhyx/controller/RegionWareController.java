package com.huaihua.hhyx.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.huaihua.hhyx.common.result.Result;
import com.huaihua.hhyx.model.sys.RegionWare;
import com.huaihua.hhyx.service.RegionWareService;
import com.huaihua.hhyx.vo.sys.RegionWareQueryVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@Api(tags = "区域管理")
@Slf4j
@RestController
@RequestMapping("/admin/sys/regionWare")
//@CrossOrigin
public class RegionWareController {

    @Resource
    private RegionWareService regionWareService;

    @GetMapping("/{page}/{limit}")
    public Result getPageList(@PathVariable("page") Long page,
                              @PathVariable("limit") Long limit,
                              RegionWareQueryVo regionWareQueryVo){
        log.info("page{},limit{},regionWareQueryVo{},",page,limit,regionWareQueryVo);
        Page<RegionWare> pageParam = new Page<>(page,limit);
        IPage<RegionWare> regionWareIPage = regionWareService.selectPage(pageParam, regionWareQueryVo);
        return Result.ok(regionWareIPage);
    }

    @ApiOperation("新增开通区域")
    @PostMapping("/save")
    public Result save(@RequestBody RegionWare regionWare){
        regionWareService.saveRegionWare(regionWare);
        return Result.ok(null);
    }

    @ApiOperation("删除")
    @DeleteMapping("/remove/{id}")
    public Result removeById(@PathVariable("id") Long id){
        boolean b = regionWareService.removeById(id);
        if (b){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }

    @ApiOperation("取消开通区域")
    @PostMapping("/updateStatus/{id}/{status}")
    public Result updateStatus(@PathVariable("id") Long id,@PathVariable("status") Integer status){
        regionWareService.updateStatusById(id,status);
        return Result.ok(null);
    }
}
