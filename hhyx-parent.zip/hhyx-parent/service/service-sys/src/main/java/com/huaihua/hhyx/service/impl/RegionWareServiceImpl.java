package com.huaihua.hhyx.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.huaihua.hhyx.common.result.ResultCodeEnum;
import com.huaihua.hhyx.mapper.RegionWareMapper;
import com.huaihua.hhyx.model.sys.RegionWare;
import com.huaihua.hhyx.service.RegionWareService;
import com.huaihua.hhyx.vo.sys.RegionWareQueryVo;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;

@Service
public class RegionWareServiceImpl extends ServiceImpl<RegionWareMapper, RegionWare> implements RegionWareService {

    @Resource
    private RegionWareMapper regionWareMapper;

    @Resource
    private RegionWareService regionWareService;

    @Override
    // 封装一个分页的方法，把分页的值和所需要的数据穿进来
    public IPage<RegionWare> selectPage(Page<RegionWare> pageParam, RegionWareQueryVo regionWareQueryVo) {
        // 从RegionWareQueryVo获取关键字KeyWord，他是一个String类型的变量
        String keyword = regionWareQueryVo.getKeyword();
        // 表示要查询的实体类的类型，也就是数据库表对应的Java类的类型，这样可以保证查询的条件和实体类类型一致，
        // 避免出现拼写出错或者类型不匹配的问题
        LambdaQueryWrapper<RegionWare> wrapper = new LambdaQueryWrapper<>();
        // 进行非空判断，判断有没有关键字传值进来
        if (!StringUtils.isEmpty(keyword)){
            // 如果穿进来的值不为空，就将传进来的关键字和数据库中的RegionName进行模糊匹配
            wrapper.like(RegionWare::getRegionName,keyword).or().like(RegionWare::getRegionName,keyword);
        }
        // 封装分页的数据和查询的值
        IPage<RegionWare> regionWareIPage = baseMapper.selectPage(pageParam,wrapper);
        return regionWareIPage;
    }

    @Override
    public void saveRegionWare(RegionWare regionWare) {
        LambdaQueryWrapper<RegionWare> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(RegionWare::getRegionId,regionWare.getRegionId());
        baseMapper.insert(regionWare);
    }

    @Override
    public void updateStatusById(Long id, Integer status) {
        RegionWare regionWare = regionWareMapper.selectById(id);
        regionWare.setStatus(status);
        regionWareMapper.updateById(regionWare);
    }

}
