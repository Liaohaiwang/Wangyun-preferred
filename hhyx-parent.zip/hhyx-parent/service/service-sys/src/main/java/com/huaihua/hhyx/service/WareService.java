package com.huaihua.hhyx.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.huaihua.hhyx.model.sys.Ware;

public interface WareService extends IService<Ware> {
}
