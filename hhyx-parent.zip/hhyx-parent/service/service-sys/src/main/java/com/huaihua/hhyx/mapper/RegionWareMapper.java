package com.huaihua.hhyx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.huaihua.hhyx.model.sys.RegionWare;

public interface RegionWareMapper extends BaseMapper<RegionWare> {
}
