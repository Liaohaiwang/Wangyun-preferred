package com.huaihua.hhyx.controller;

import com.huaihua.hhyx.common.result.Result;
import com.huaihua.hhyx.service.WareService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@Slf4j
@RestController
@RequestMapping("/admin/sys/ware")
@Api(tags = "获取全部仓库")
//@CrossOrigin
public class WareController {

    @Resource
    private WareService wareService;

    @ApiOperation("获取全部仓库")
    @GetMapping("/findAllList")
    public Result findAllList(){
        return Result.ok(wareService.list());
    }
}
