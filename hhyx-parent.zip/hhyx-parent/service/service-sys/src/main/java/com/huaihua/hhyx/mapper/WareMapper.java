package com.huaihua.hhyx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.huaihua.hhyx.model.sys.Ware;

public interface WareMapper extends BaseMapper<Ware> {
}
