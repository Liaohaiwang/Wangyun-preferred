package com.huaihua.hhyx.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.huaihua.hhyx.model.sys.RegionWare;
import com.huaihua.hhyx.vo.sys.RegionWareQueryVo;

public interface RegionWareService extends IService<RegionWare> {

    // 开通区域列表
    IPage<RegionWare> selectPage(Page<RegionWare> pageParam, RegionWareQueryVo regionWareQueryVo);

    void saveRegionWare(RegionWare regionWare);

    void updateStatusById(Long id, Integer status);
}
