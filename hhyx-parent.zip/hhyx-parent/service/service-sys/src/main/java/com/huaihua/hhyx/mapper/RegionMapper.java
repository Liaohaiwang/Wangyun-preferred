package com.huaihua.hhyx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.huaihua.hhyx.model.sys.Region;

public interface RegionMapper extends BaseMapper<Region> {
}
