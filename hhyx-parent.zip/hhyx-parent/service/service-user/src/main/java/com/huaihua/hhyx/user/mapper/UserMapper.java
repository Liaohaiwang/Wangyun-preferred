package com.huaihua.hhyx.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.huaihua.hhyx.model.user.User;

public interface UserMapper extends BaseMapper<User> {
}
