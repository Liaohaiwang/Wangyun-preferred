package com.huaihua.hhyx.user.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.huaihua.hhyx.model.user.User;
import com.huaihua.hhyx.vo.user.LeaderAddressVo;

public interface UserService extends IService<User> {

    User getByOpenid(String openId);

    LeaderAddressVo getLeaderAddressVoByUserId(String openId);
}
