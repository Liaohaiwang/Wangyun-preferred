package com.huaihua.hhyx.user.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.huaihua.hhyx.model.user.User;
import com.huaihua.hhyx.model.user.UserDelivery;
import com.huaihua.hhyx.user.mapper.UserMapper;
import com.huaihua.hhyx.user.service.UserService;
import com.huaihua.hhyx.vo.user.LeaderAddressVo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    @Resource
    private UserMapper userMapper;

    @Override
    public User getByOpenid(String openId) {
        return userMapper.selectOne(new LambdaQueryWrapper<User>().eq(User::getOpenId,openId));
    }

    @Override
    public LeaderAddressVo getLeaderAddressVoByUserId(String openId) {
        LambdaQueryWrapper<UserDelivery> wrapper = new LambdaQueryWrapper<>();
        // 根据用户id进行查询
        wrapper.eq(UserDelivery::getUserId,openId);
        // 查询用户交互信息是否为默认
        wrapper.eq(UserDelivery::getIsDefault,1);
        return null;
    }
}
