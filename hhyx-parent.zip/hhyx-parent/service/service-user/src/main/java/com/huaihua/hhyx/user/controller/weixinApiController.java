package com.huaihua.hhyx.user.controller;

import com.alibaba.fastjson.JSONObject;
import com.huaihua.hhyx.common.exception.HhyxException;
import com.huaihua.hhyx.common.result.Result;
import com.huaihua.hhyx.common.result.ResultCodeEnum;
import com.huaihua.hhyx.enums.UserType;
import com.huaihua.hhyx.model.user.User;
import com.huaihua.hhyx.user.service.UserService;
import com.huaihua.hhyx.user.util.ConstantPropertiesUtil;
import com.huaihua.hhyx.user.util.HttpClientUtils;
import com.huaihua.hhyx.vo.user.LeaderAddressVo;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RequestMapping("/api/user/weixin")
@RestController
public class weixinApiController {

    @Resource
    private UserService userService;

    @Resource
    private RedisTemplate redisTemplate;

    @ApiOperation("微信登录获取openid(小程序)")
    @GetMapping("/wxLogin/{code}")
    public Result callback(@PathVariable("code") String code){
        // 获取授权临时票据
        System.out.println("微信授权服务器回调。。。。。"+code);
        if (StringUtils.isEmpty(code)){
            throw new HhyxException(ResultCodeEnum.ILLEGAL_CALLBACK_REQUEST_ERROR);
        }

        // 使用code和appid以及appscrect换取access_token
        // 将每个参数和URL拼接起来，形成一个完整的URL地址
        StringBuffer baseAccessTokenUrl = new StringBuffer()
                .append("https://api.weixin.qq.com/sns/jscode2session")
                .append("?appid=%s")
                .append("&secret=%s")
                .append("&js_code=%s")
                .append("&grant_type=authorization_code");

        String accessTokenUrl = String.format(baseAccessTokenUrl.toString(),
                ConstantPropertiesUtil.WX_OPEN_APP_ID,
                ConstantPropertiesUtil.WX_OPEN_APP_SECRET,
                code);

        String result = null;
        try {
            // 将拼接后的URL地址赋值给result
            result = HttpClientUtils.get(accessTokenUrl);
        } catch (Exception e) {
            // 如果发生异常，抛出自写的异常(获取accessToken失败)
            throw new HhyxException(ResultCodeEnum.FETCH_ACCESSTOKEN_FAILD);
        }

        System.out.println("使用code换取的access_token结果 = " + result);
        // 将结果解析为JSOn格式
        JSONObject resultJson = JSONObject.parseObject(result);
        // 检查一个json格式对象(resultJson)中是否有errcode这个键，如果有，说明调用
        // codeSession接口错误，就需要抛出一个自定义异常，方便处理登录时失败的情况
        if (resultJson.getString("errcode") != null){
            throw new HhyxException(ResultCodeEnum.FETCH_ACCESSTOKEN_FAILD);
        }

        // 从resultJson获取key值然后赋值给accessToken
        String accessToken = resultJson.getString("session_key");
        String openId = resultJson.getString("openid");

        // 根据access_token获取微信用户的基本信息
        // 先根据openid进行数据库查询
        User user = userService.getByOpenid(openId);

        // 如果没有查到用户信息，那么调用微信个人信息获取的接口
        if (user != null){
            user = new User();
            // id
            user.setOpenId(openId);
            // 昵称
            user.setNickName(openId);
            // 头像
            user.setPhotoUrl("");
            // 用户类型
            user.setUserType(UserType.USER);
            // 是否为新用户
            user.setIsNew(0);
            userService.save(user);
        }

        // 根据用户id获取团长位置
        LeaderAddressVo leaderAddressVo = userService.getLeaderAddressVoByUserId(openId);
        return null;
    }
}
