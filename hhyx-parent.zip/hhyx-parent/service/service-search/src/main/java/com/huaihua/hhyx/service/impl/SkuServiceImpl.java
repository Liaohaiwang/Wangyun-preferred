package com.huaihua.hhyx.service.impl;

import com.alibaba.fastjson.JSON;
import com.huaihua.hhyx.client.ProductFeignClient;
import com.huaihua.hhyx.enums.SkuType;
import com.huaihua.hhyx.model.product.Category;
import com.huaihua.hhyx.model.product.SkuInfo;
import com.huaihua.hhyx.model.search.SkuEs;
import com.huaihua.hhyx.repository.SkuEsRepository;
import com.huaihua.hhyx.service.SkuService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Slf4j
@Service
public class SkuServiceImpl implements SkuService {

    @Resource
    private ProductFeignClient productFeignClient;

    @Resource
    private SkuEsRepository skuEsRepository;
    /**
     * 上架商品
     * @param skuId
     */
    @Override
    public void upperSku(Long skuId) {
        log.info("skuId{},",skuId);
        SkuEs skuEs = new SkuEs();

        // 查询sku信息
        SkuInfo skuInfo = productFeignClient.getSkuInfo(skuId);
        if (skuInfo != null){
            // 查询分类
            Category category = productFeignClient.getCategory(skuInfo.getCategoryId());
            if (category != null){
                skuEs.setCategoryId(category.getId());
                skuEs.setCategoryName(category.getName());
            }
            skuEs.setId(skuInfo.getId());
            skuEs.setKeyword(skuInfo.getSkuName()+","+skuEs.getCategoryName());
            skuEs.setWareId(skuInfo.getWareId());
            skuEs.setIsNewPerson(skuInfo.getIsNewPerson());
            skuEs.setImgUrl(skuInfo.getImgUrl());
            skuEs.setTitle(skuInfo.getSkuName());
            if (skuInfo.getSkuType() == SkuType.COMMON.getCode()){
                skuEs.setSkuType(0);
                skuEs.setPrice(skuInfo.getPrice().doubleValue());
                skuEs.setStock(skuInfo.getStock());
                skuEs.setSale(skuInfo.getSale());
                skuEs.setPerLimit(skuInfo.getPerLimit());
            }else {
                // TODO 待完善
            }
            SkuEs save = skuEsRepository.save(skuEs);
            log.info("upperSku: " + JSON.toJSONString(save));
        }
    }

    /**
     * 下架商品
     * @param skuId
     */
    @Override
    public void lowerSku(Long skuId) {
        this.skuEsRepository.deleteById(skuId);
    }
}
