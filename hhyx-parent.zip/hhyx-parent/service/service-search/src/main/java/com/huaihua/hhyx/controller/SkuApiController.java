package com.huaihua.hhyx.controller;

import com.huaihua.hhyx.common.result.Result;
import com.huaihua.hhyx.service.SkuService;
import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@Api(tags = "SkuApiController")
@RestController
@RequestMapping("/api/search/sku")
public class SkuApiController {

    @Resource
    private SkuService skuService;

    // 上架
    @GetMapping("/inner/upperSku/{skuId}")
    private Result upperSku(@PathVariable("skuId") Long skuId){
        skuService.upperSku(skuId);
        return Result.ok();
    }

    //下架
    @GetMapping("/inner/lowerSku/{skuId}")
    private Result lowerSku(@PathVariable("skuId") Long skuId){
        skuService.lowerSku(skuId);
        return Result.ok();
    }
}
