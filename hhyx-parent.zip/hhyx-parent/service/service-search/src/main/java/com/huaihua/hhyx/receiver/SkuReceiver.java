package com.huaihua.hhyx.receiver;

import com.huaihua.hhyx.config.MqConst;
import com.huaihua.hhyx.service.SkuService;
import com.rabbitmq.client.Channel;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
public class SkuReceiver {

    @Resource
    private SkuService skuService;

    @RabbitListener(bindings = @QueueBinding(
            value = @Queue(value = MqConst.QUEUE_GOODS_UPPER,durable = "true"),
            exchange = @Exchange(value = MqConst.EXCHANGE_GOODS_DIRECT),
            key = {MqConst.ROUTING_GOODS_UPPER}
    ))
    public void upperSku(Long id, Message message, Channel channel) throws Exception{
        if (id != null){
            skuService.upperSku(id);
        }
        /**
         * 第一个参数：表示收到的消息的标号
         * 第二个参数：如果为true表示可以签收多个消息
         */
        channel.basicAck(message.getMessageProperties().getDeliveryTag(),false);
    }


    /**
     * 商品下架
     * @param id
     * @param message
     * @param channel
     * @throws Exception
     */
    @RabbitListener(bindings = @QueueBinding(
            value = @Queue(value = MqConst.QUEUE_GOODS_LOWER,durable = "true"),
            exchange = @Exchange(value = MqConst.EXCHANGE_GOODS_DIRECT),
            key = {MqConst.ROUTING_GOODS_LOWER}
    ))
    public void lowerSku(Long id,Message message,Channel channel)throws Exception{
        if (id != null){
            skuService.lowerSku(id);
        }

        /**
         * 第一个参数：表示收到的消息的标号
         * 第二个参数：如果为true表示可以接收多个消息
         */
        channel.basicAck(message.getMessageProperties().getDeliveryTag(),false);
    }
}
