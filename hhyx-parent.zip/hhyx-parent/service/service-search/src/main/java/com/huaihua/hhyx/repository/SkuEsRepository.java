package com.huaihua.hhyx.repository;

import com.huaihua.hhyx.model.search.SkuEs;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

public interface SkuEsRepository extends ElasticsearchRepository<SkuEs,Long> {
}
