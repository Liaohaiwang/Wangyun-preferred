package com.huaihua.hhyx.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.huaihua.hhyx.mapper.SkuAttrValueMapper;
import com.huaihua.hhyx.model.product.SkuAttrValue;
import com.huaihua.hhyx.service.SkuAttrValueService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * spu属性值 服务实现类
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
@Service
public class SkuAttrValueServiceImpl extends ServiceImpl<SkuAttrValueMapper, SkuAttrValue> implements SkuAttrValueService {

    @Override
    public List<SkuAttrValue> findBySkuId(Long id) {
        LambdaQueryWrapper<SkuAttrValue> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(SkuAttrValue::getAttrId,id);
        List<SkuAttrValue> skuAttrValues = baseMapper.selectList(wrapper);
        return skuAttrValues;
    }
}
