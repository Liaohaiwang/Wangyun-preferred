package com.huaihua.hhyx.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.huaihua.hhyx.common.result.Result;
import com.huaihua.hhyx.model.product.SkuInfo;
import com.huaihua.hhyx.service.SkuInfoService;
import com.huaihua.hhyx.vo.product.SkuInfoQueryVo;
import com.huaihua.hhyx.vo.product.SkuInfoVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * sku信息 前端控制器
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
@Api(tags = "商品平台(sku)管理")
@RestController
@RequestMapping("/admin/product/skuInfo")
@Slf4j
//@CrossOrigin
public class SkuInfoController {

    @Resource
    private SkuInfoService skuInfoService;

    @ApiOperation("分页查询")
    @GetMapping("/{page}/{limit}")
    public Result getPageList(@PathVariable("page") Long page,
                              @PathVariable("limit") Long limit,
                              SkuInfoQueryVo skuInfoQueryVo){
        IPage<SkuInfo> page1 = new Page<>(page,limit);
        IPage<SkuInfo> pageList = skuInfoService.getPageList(page1, skuInfoQueryVo);
        return Result.ok(pageList);
    }

    @ApiOperation("根据id获取信息")
    @GetMapping("/get/{id}")
    public Result getById(@PathVariable("id") Long id){
        SkuInfoVo byId = skuInfoService.getSkuInfoVo(id);
        return Result.ok(byId);
    }

    @ApiOperation("新增")
    @PostMapping("/save")
    public Result save(@RequestBody SkuInfoVo skuInfoVo){
        skuInfoService.saveBySkuInfo(skuInfoVo);
        return Result.ok();
    }

    @ApiOperation("修改")
    @PutMapping("/update")
    public Result updateById(@RequestBody SkuInfoVo skuInfoVo){
        skuInfoService.updateSkuInfo(skuInfoVo);
        return Result.ok();
    }

    @ApiOperation("删除")
    @DeleteMapping("/remove/{id}")
    public Result removeById(@PathVariable("id") Long id){
        boolean b = skuInfoService.removeById(id);
        if (b){
            return Result.ok();
        }else {
            return Result.fail();
        }
    }

    @ApiOperation("根据id列表删除")
    @DeleteMapping("/batchRemove")
    public Result removeRows(@RequestBody List<Long> ids){
        boolean b = skuInfoService.removeByIds(ids);
        if (b){
            return Result.ok();
        }else {
            return Result.fail();
        }
    }

    @ApiOperation("商品上架")
    @GetMapping("/publish/{id}/{status}")
    public Result publish(@PathVariable("id") Long id,@PathVariable("status") Integer status){
        skuInfoService.publish(id,status);
        return Result.ok();
    }

    @ApiOperation("商品审核")
    @GetMapping("/check/{id}/{status}")
    public Result check(@PathVariable("id") Long id,@PathVariable("status") Integer status){
        skuInfoService.check(id,status);
        return Result.ok();
    }

    @ApiOperation("新人专享")
    @GetMapping("/isNewPerson/{id}/{status}")
    public Result isNewPerson(@PathVariable("id") Long id,
                              @PathVariable("status") Integer status){
        skuInfoService.isNewPerson(id,status);
        return Result.ok();
    }
}

