package com.huaihua.hhyx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 三级分类表 Mapper 接口
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
public interface BaseCategoryTrademarkMapper{

}
