package com.huaihua.hhyx.service.impl;

import com.huaihua.hhyx.service.SkuDetailService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * spu属性值 服务实现类
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
@Service
public class SkuDetailServiceImpl implements SkuDetailService {

}
