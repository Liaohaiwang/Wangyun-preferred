package com.huaihua.hhyx.service.impl;

import com.huaihua.hhyx.mapper.RegionWareMapper;
import com.huaihua.hhyx.model.sys.RegionWare;
import com.huaihua.hhyx.service.RegionWareService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 城市仓库关联表 服务实现类
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
@Service
public class RegionWareServiceImpl extends ServiceImpl<RegionWareMapper, RegionWare> implements RegionWareService {

}
