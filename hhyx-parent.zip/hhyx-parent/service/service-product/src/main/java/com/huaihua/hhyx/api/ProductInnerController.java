package com.huaihua.hhyx.api;

import com.huaihua.hhyx.common.result.Result;
import com.huaihua.hhyx.model.product.Category;
import com.huaihua.hhyx.model.product.SkuInfo;
import com.huaihua.hhyx.service.CategoryService;
import com.huaihua.hhyx.service.SkuInfoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@Slf4j
@RequestMapping("/api/product")
@RestController
//@CrossOrigin
@Api
public class ProductInnerController {

    @Resource
    private CategoryService categoryService;

    @Resource
    private SkuInfoService skuInfoService;

    @ApiOperation("根据分类id获取信息")
    @GetMapping("/inner/getCategory/{categoryId}")
    public Category getCategory(@PathVariable("categoryId") Long categoryId){
        Category byId = categoryService.getById(categoryId);
        return byId;
    }

    @ApiOperation("根据skuId获取sku信息")
    @GetMapping("/inner/getSkuInfo/{skuId}")
    public SkuInfo getSkuInfo(@PathVariable("skuId") Long skuId){
        SkuInfo byId = skuInfoService.getById(skuId);
        return byId;
    }
}
