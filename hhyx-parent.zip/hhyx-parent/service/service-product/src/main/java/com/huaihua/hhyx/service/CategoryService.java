package com.huaihua.hhyx.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.huaihua.hhyx.model.product.AttrGroup;
import com.huaihua.hhyx.model.product.Category;
import com.baomidou.mybatisplus.extension.service.IService;
import com.huaihua.hhyx.vo.product.CategoryQueryVo;

import java.util.List;

/**
 * <p>
 * 商品三级分类 服务类
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
public interface CategoryService extends IService<Category> {

    IPage<Category> pageList(Page<Category> page1, CategoryQueryVo categoryQueryVo);

    List<Category> findAllListBySort();

    List<Category> findCategoryList(List<Long> categoryIdList);
}
