package com.huaihua.hhyx.service.impl;

import com.huaihua.hhyx.mapper.SkuStockHistoryMapper;
import com.huaihua.hhyx.model.product.SkuStockHistory;
import com.huaihua.hhyx.service.SkuStockHistoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * sku的库存历史记录 服务实现类
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
@Service
public class SkuStockHistoryServiceImpl extends ServiceImpl<SkuStockHistoryMapper, SkuStockHistory> implements SkuStockHistoryService {

}
