package com.huaihua.hhyx.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * mq去重表 前端控制器
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
@RestController
@RequestMapping("/admin/product/mq-repeat-record")
public class MqRepeatRecordController {

}

