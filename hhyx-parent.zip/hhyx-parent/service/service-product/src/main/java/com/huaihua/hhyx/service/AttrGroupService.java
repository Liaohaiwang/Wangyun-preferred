package com.huaihua.hhyx.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.huaihua.hhyx.model.product.AttrGroup;
import com.baomidou.mybatisplus.extension.service.IService;
import com.huaihua.hhyx.model.product.Category;
import com.huaihua.hhyx.vo.product.AttrGroupQueryVo;

import java.util.List;

/**
 * <p>
 * 属性分组 服务类
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
public interface AttrGroupService extends IService<AttrGroup> {

    IPage<AttrGroup> getPageListAndLimit(Page<AttrGroup> page1, AttrGroupQueryVo attrGroupQueryVo);

    List<AttrGroup> findAllListBy();
}
