package com.huaihua.hhyx.service.impl;

import com.huaihua.hhyx.mapper.WareMapper;
import com.huaihua.hhyx.model.sys.Ware;
import com.huaihua.hhyx.service.WareService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 仓库表 服务实现类
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
@Service
public class WareServiceImpl extends ServiceImpl<WareMapper, Ware> implements WareService {

}
