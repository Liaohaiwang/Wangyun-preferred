package com.huaihua.hhyx.controller;


import com.huaihua.hhyx.common.result.Result;
import com.huaihua.hhyx.model.product.Attr;
import com.huaihua.hhyx.service.AttrService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 商品属性 前端控制器
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
@Api(tags = "商品属性")
@Slf4j
@RestController
@RequestMapping("/admin/product/attr")
//@CrossOrigin(origins = "*")
public class AttrController {

    @Resource
    private AttrService attrService;

    @ApiOperation("根据属性分组id 获取属性列表")
    @GetMapping("/{groupId}")
    public Result getList(@PathVariable("groupId") Long groupId){
        log.info("groupId{},",groupId);
        List<Attr> allList = attrService.findAllList(groupId);
        return Result.ok(allList);
    }

    @ApiOperation("根据id获取到商品属性")
    @GetMapping("/get/{id}")
    public Result getById(@PathVariable("id") Long id){
        Attr byId = attrService.getById(id);
        return Result.ok(byId);
    }

    @ApiOperation("新增")
    @PostMapping("/save")
    public Result save(@RequestBody Attr attr){
        boolean save = attrService.save(attr);
        if (save){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }

    @ApiOperation("修改")
    @PutMapping("/update")
    public Result updateById(@RequestBody Attr attr){
        boolean b = attrService.updateById(attr);
        if (b){
            return Result.ok(null);
        }else {
            return  Result.fail(null);
        }
    }

    @ApiOperation("根据id删除")
    @DeleteMapping("/remove/{id}")
    public Result removeById(@PathVariable("id") Long id){
        boolean b = attrService.removeById(id);
        if (b){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }

    @ApiOperation("根据id列表进行删除")
    @DeleteMapping("/batchRemove")
    public Result removeList(@RequestBody List<Long> ids){
        boolean b = attrService.removeByIds(ids);
        if (b){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }
}

