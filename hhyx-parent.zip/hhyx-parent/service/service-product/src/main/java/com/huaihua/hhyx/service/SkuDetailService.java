package com.huaihua.hhyx.service;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * spu属性值 服务类
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
public interface SkuDetailService{

}
