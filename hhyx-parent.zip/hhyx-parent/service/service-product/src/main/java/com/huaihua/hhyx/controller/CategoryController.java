package com.huaihua.hhyx.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.huaihua.hhyx.common.result.Result;
import com.huaihua.hhyx.model.product.Category;
import com.huaihua.hhyx.service.CategoryService;
import com.huaihua.hhyx.vo.product.CategoryQueryVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 商品三级分类 前端控制器
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
@Api(tags = "商品分类管理")
@Slf4j
@RestController
@RequestMapping("/admin/product/category")
//@CrossOrigin
public class CategoryController {

    @Resource
    private CategoryService categoryService;

    @ApiOperation("商品展示")
    @GetMapping("/{page}/{limit}")
    public Result listPage(@PathVariable("page") Long page,
                           @PathVariable("limit") Long limit,
                           CategoryQueryVo categoryQueryVo){
        Page<Category> page1 = new Page<>(page,limit);
        IPage<Category> categoryIPage = categoryService.pageList(page1,categoryQueryVo);
        return Result.ok(categoryIPage);
    }

    @ApiOperation("新增")
    @PostMapping("/save")
    public Result save(@RequestBody Category category){
        boolean save = categoryService.save(category);
        if (save){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }


    @ApiOperation("修改")
    @PutMapping("/update")
    public Result updateById(@RequestBody Category category){
        boolean b = categoryService.updateById(category);
        if (b){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }

    @ApiOperation("删除")
    @DeleteMapping("/remove/{id}")
    public Result removeById(@PathVariable("id") Long id){
        boolean b = categoryService.removeById(id);
        if (b){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }

    @ApiOperation("根据id列表删除商品分类")
    @DeleteMapping("/batchRemove")
    public Result removeRows(@RequestBody List<Long> ids){
        boolean b = categoryService.removeByIds(ids);
        if (b){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }

    @ApiOperation("获取全部商品的分类")
    @GetMapping("/findAllList")
    public Result findAllList(){
        List<Category> allListBySort = categoryService.findAllListBySort();
        return Result.ok(allListBySort);
    }

    @ApiOperation("获取商品分类信息")
    @GetMapping("/get/{id}")
    public Result getById(@PathVariable("id") Long id){
        Category byId = categoryService.getById(id);
        return Result.ok(byId);
    }
}

