package com.huaihua.hhyx.mapper;

import com.huaihua.hhyx.model.product.Category;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 商品三级分类 Mapper 接口
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
public interface CategoryMapper extends BaseMapper<Category> {

}
