package com.huaihua.hhyx.mapper;

import com.huaihua.hhyx.model.product.Comment;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 商品评价 Mapper 接口
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
public interface CommentMapper extends BaseMapper<Comment> {

}
