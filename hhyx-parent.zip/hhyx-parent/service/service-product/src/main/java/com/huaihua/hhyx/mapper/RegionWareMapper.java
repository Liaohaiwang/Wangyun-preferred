package com.huaihua.hhyx.mapper;

import com.huaihua.hhyx.model.sys.RegionWare;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 城市仓库关联表 Mapper 接口
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
public interface RegionWareMapper extends BaseMapper<RegionWare> {

}
