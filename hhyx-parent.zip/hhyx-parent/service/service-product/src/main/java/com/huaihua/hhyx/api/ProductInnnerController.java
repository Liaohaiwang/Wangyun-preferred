package com.huaihua.hhyx.api;

import com.huaihua.hhyx.model.product.Category;
import com.huaihua.hhyx.model.product.SkuInfo;
import com.huaihua.hhyx.service.CategoryService;
import com.huaihua.hhyx.service.SkuInfoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("api/product")
@SuppressWarnings({"unchecked","rawtypes"})
public class ProductInnnerController {

    @Resource
    private SkuInfoService skuInfoService;

    @Resource
    private CategoryService categoryService;

    @ApiOperation("批量获取sku信息")
    @PostMapping("/inner/findSkuInfoList")
    public List<SkuInfo> findSkuInfoList(@RequestBody List<Long> skuInfoList){
        return skuInfoService.findSkuInfoList(skuInfoList);
    }

    @ApiOperation("根据关键字获取sku列表")
    @GetMapping("/inner/findSkuInfoByKeyword/{keyword}")
    public List<SkuInfo> skuInfoList(@PathVariable("keyword") String keyword){
        return skuInfoService.skuInfoList(keyword);
    }

    @ApiOperation("批量获取分类信息")
    @PostMapping("inner/findCategoryList")
    public List<Category> findCategoryList(@RequestBody List<Long> categoryIdList){
        return categoryService.findCategoryList(categoryIdList);
    }
}
