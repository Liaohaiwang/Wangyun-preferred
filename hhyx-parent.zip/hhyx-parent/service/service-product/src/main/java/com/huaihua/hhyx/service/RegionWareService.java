package com.huaihua.hhyx.service;

import com.huaihua.hhyx.model.sys.RegionWare;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 城市仓库关联表 服务类
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
public interface RegionWareService extends IService<RegionWare> {

}
