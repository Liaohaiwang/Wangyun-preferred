package com.huaihua.hhyx.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.huaihua.hhyx.common.result.Result;
import com.huaihua.hhyx.model.product.AttrGroup;
import com.huaihua.hhyx.service.AttrGroupService;
import com.huaihua.hhyx.vo.product.AttrGroupQueryVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 属性分组 前端控制器
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
@Api(tags = "属性分组")
@Slf4j
@RestController
@RequestMapping("/admin/product/attrGroup")
//@CrossOrigin
public class AttrGroupController {

    @Resource
    private AttrGroupService attrGroupService;

    @ApiOperation("分页查询")
    @GetMapping("/{page}/{limit}")
    public Result getPageList(@PathVariable("page") Long page,
                              @PathVariable("limit") Long limit,
                              AttrGroupQueryVo attrGroupQueryVo){
        Page<AttrGroup> page1 = new Page<>(page,limit);
        IPage<AttrGroup> pageListAndLimit = attrGroupService.getPageListAndLimit(page1, attrGroupQueryVo);
        return Result.ok(pageListAndLimit);
    }

    @ApiOperation("获取属性分类信息")
    @GetMapping("/get/{id}")
    public Result getById(@PathVariable("id") Long id){
        AttrGroup byId = attrGroupService.getById(id);
        return Result.ok(byId);
    }

    @ApiOperation("增加")
    @PostMapping("/save")
    public Result save(@RequestBody AttrGroup attrGroup){
        boolean save = attrGroupService.save(attrGroup);
        if (save){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }

    @ApiOperation("修改")
    @PutMapping("/update")
    public Result updateById(@RequestBody AttrGroup attrGroup){
        boolean b = attrGroupService.updateById(attrGroup);
        if (b){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }

    @ApiOperation("根据id删除")
    @DeleteMapping("/remove/{id}")
    public Result removeById(@PathVariable("id") Long id){
        boolean b = attrGroupService.removeById(id);
        if (b){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }

    @ApiOperation("根据id列表删除")
    @DeleteMapping("/batchRemove")
    public Result removeRows(@RequestBody List<Long> ids){
        boolean b = attrGroupService.removeByIds(ids);
        if (b){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }

    @ApiOperation("获取全部属性分组")
    @GetMapping("/findAllList")
    public Result findAllList(){
        List<AttrGroup> allListBy = attrGroupService.findAllListBy();
        return Result.ok(allListBy);
    }

}

