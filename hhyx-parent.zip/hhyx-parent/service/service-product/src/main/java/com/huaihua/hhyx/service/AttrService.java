package com.huaihua.hhyx.service;

import com.huaihua.hhyx.model.product.Attr;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 商品属性 服务类
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
public interface AttrService extends IService<Attr> {

    List<Attr> findAllList(Long groupId);
}
