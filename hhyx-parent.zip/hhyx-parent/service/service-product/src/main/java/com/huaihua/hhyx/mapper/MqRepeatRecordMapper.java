package com.huaihua.hhyx.mapper;

import com.huaihua.hhyx.model.base.MqRepeatRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * mq去重表 Mapper 接口
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
public interface MqRepeatRecordMapper extends BaseMapper<MqRepeatRecord> {

}
