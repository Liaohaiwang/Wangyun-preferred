package com.huaihua.hhyx.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.huaihua.hhyx.mapper.AttrGroupMapper;
import com.huaihua.hhyx.model.product.AttrGroup;
import com.huaihua.hhyx.service.AttrGroupService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.huaihua.hhyx.vo.product.AttrGroupQueryVo;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 属性分组 服务实现类
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
@Service
public class AttrGroupServiceImpl extends ServiceImpl<AttrGroupMapper, AttrGroup> implements AttrGroupService {

    @Resource
    private AttrGroupService attrGroupService;

    @Override
    public IPage<AttrGroup> getPageListAndLimit(Page<AttrGroup> page1, AttrGroupQueryVo attrGroupQueryVo) {
        String name = attrGroupQueryVo.getName();
        LambdaQueryWrapper<AttrGroup> wrapper = new LambdaQueryWrapper<>();
        if (!StringUtils.isEmpty(name)){
            wrapper.like(AttrGroup::getName,name);
        }
        Page<AttrGroup> page = attrGroupService.page(page1, wrapper);
        return page;
    }

    // 查询所有属性分组
    @Override
    public List<AttrGroup> findAllListBy() {
        return this.list();
    }
}
