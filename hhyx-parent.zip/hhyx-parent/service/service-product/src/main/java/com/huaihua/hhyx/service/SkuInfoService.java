package com.huaihua.hhyx.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.huaihua.hhyx.model.product.SkuInfo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.huaihua.hhyx.vo.product.SkuInfoQueryVo;
import com.huaihua.hhyx.vo.product.SkuInfoVo;

import java.util.List;

/**
 * <p>
 * sku信息 服务类
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
public interface SkuInfoService extends IService<SkuInfo> {

    // 分页查询
    IPage<SkuInfo> getPageList(IPage<SkuInfo> page1, SkuInfoQueryVo skuInfoQueryVo);

    /**
     * 添加商品
     * @param skuInfoVo
     */
    void saveBySkuInfo(SkuInfoVo skuInfoVo);


    /**
     * 获取商品
     * @param id
     * @return
     */
    SkuInfoVo getSkuInfoVo(Long id);

    // 修改商品
    void updateSkuInfo(SkuInfoVo skuInfoVo);

    // 商品审核
    void check(Long id, Integer status);

    // 商品上架
    void publish(Long id, Integer status);

    // 新人专享
    void isNewPerson(Long id, Integer status);

    /**
     * 批量获取sku信息
     * @param skuInfoList
     * @return
     */
    List<SkuInfo> findSkuInfoList(List<Long> skuInfoList);

    /**
     * 根据关键字获取sku列表
     * @param keyword
     * @return
     */
    List<SkuInfo> skuInfoList(String keyword);
}
