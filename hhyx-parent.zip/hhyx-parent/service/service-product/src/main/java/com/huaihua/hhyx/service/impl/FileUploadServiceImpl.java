package com.huaihua.hhyx.service.impl;


import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.huaihua.hhyx.service.FileUploadService;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

@Service
public class FileUploadServiceImpl implements FileUploadService {

    @Value("${aliyun.oss.endpoint}")
    private String endPoint;

    @Value("${aliyun.oss.accessKeyId}")
    private String accessKey;

    @Value("${aliyun.oss.accessKeySecret}")
    private String secreKey;

    @Value("${aliyun.oss.bucket}")
    private String buckName;

    @Override
    public String fileUpload(MultipartFile file) throws Exception {
        // 创建OSSClient实例
        OSS ossClient = new OSSClientBuilder().build(endPoint,accessKey,secreKey);
        String url = "";
        try {
            // 上传文件流
            InputStream inputStream = file.getInputStream();
            String filename = file.getOriginalFilename();
            // 生成随机唯一值,使用uuid,添加到文件名称里面
            String uuid = UUID.randomUUID().toString().replaceAll("-", "");
            filename = uuid+filename;
            // 按照当前日期，创建文件夹，上传到创建文件名称里面
            // 2023/08/02.jpg
            String timeUrl = new DateTime().toString("yyyy-MM-dd");
            filename = timeUrl+"/"+filename;
            // 调用方法实现文件上传
            ossClient.putObject(buckName,filename,inputStream);
            // 关闭ossClient
            ossClient.shutdown();
            // 上传之后文件路径
            // https://hhyx-huaihua.oss-cn-beijing.aliyuncs.com/01.jpg
            url = "https://"+buckName+"."+endPoint+"/"+filename;
        }catch (IOException e){
            e.printStackTrace();
            return null;
        }finally {
            if (ossClient != null){
                ossClient.shutdown();
            }
        }
        // 返回
        return url;
    }
}
