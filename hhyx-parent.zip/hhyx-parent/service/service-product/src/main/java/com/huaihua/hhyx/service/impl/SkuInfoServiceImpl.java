package com.huaihua.hhyx.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.huaihua.hhyx.config.MqConst;
import com.huaihua.hhyx.mapper.SkuInfoMapper;
import com.huaihua.hhyx.model.product.SkuAttrValue;
import com.huaihua.hhyx.model.product.SkuImage;
import com.huaihua.hhyx.model.product.SkuInfo;
import com.huaihua.hhyx.model.product.SkuPoster;
import com.huaihua.hhyx.service.*;
import com.huaihua.hhyx.vo.product.SkuInfoQueryVo;
import com.huaihua.hhyx.vo.product.SkuInfoVo;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * sku信息 服务实现类
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
@Service
public class SkuInfoServiceImpl extends ServiceImpl<SkuInfoMapper, SkuInfo> implements SkuInfoService {

    @Resource
    private SkuInfoMapper skuInfoMapper;

    @Resource
    private SkuPosterService skuPosterService;

    @Resource
    private SkuImageService skuImageService;

    @Resource
    private SkuAttrValueService skuAttrValueService;

    @Resource
    private RabbitService rabbitService;

    @Override
    public IPage<SkuInfo> getPageList(IPage<SkuInfo> page1, SkuInfoQueryVo skuInfoQueryVo) {
        String skuType = skuInfoQueryVo.getSkuType();
        String keyword = skuInfoQueryVo.getKeyword();
        Long categoryId = skuInfoQueryVo.getCategoryId();
        LambdaQueryWrapper<SkuInfo> wrapper = new LambdaQueryWrapper<>();
        if (!StringUtils.isEmpty(keyword)){
            wrapper.like(SkuInfo::getSkuName,keyword);
        }
        if (!StringUtils.isEmpty(skuType)){
            wrapper.eq(SkuInfo::getSkuType,skuType);
        }
        if (!StringUtils.isEmpty(categoryId)){
            wrapper.eq(SkuInfo::getCategoryId,categoryId);
        }

        IPage<SkuInfo> skuInfoIPage = baseMapper.selectPage(page1, wrapper);
        return skuInfoIPage;
    }

    /**
     * 获取商品
     * @param id
     * @return
     */
    @Override
    public SkuInfoVo getSkuInfoVo(Long id) {
        return getSkuInfoDB(id);
    }

    private SkuInfoVo getSkuInfoDB(Long id) {
        SkuInfoVo skuInfoVo = new SkuInfoVo();

        SkuInfo skuInfo = skuInfoMapper.selectById(id);
        // skuImagesService skuPosterService skuAttrValueService分别添加方法
        List<SkuImage> skuImages = skuImageService.findBySkuId(id);
        List<SkuPoster> skuPosters = skuPosterService.findBySkuId(id);
        List<SkuAttrValue> skuAttrValues = skuAttrValueService.findBySkuId(id);

        BeanUtils.copyProperties(skuInfo,skuInfoVo);
        skuInfoVo.setSkuImagesList(skuImages);
        skuInfoVo.setSkuPosterList(skuPosters);
        skuInfoVo.setSkuAttrValueList(skuAttrValues);
        return skuInfoVo;
    }


    /**
     * 修改商品
     * @param skuInfoVo
     */
    @Transactional(rollbackFor = {Exception.class})
    @Override
    public void updateSkuInfo(SkuInfoVo skuInfoVo) {
        Long id = skuInfoVo.getId();
        // 更新sku信息
        this.updateById(skuInfoVo);

        // 保存sku详情
        skuPosterService.remove(new LambdaQueryWrapper<SkuPoster>().eq(SkuPoster::getSkuId,id));
        // 保存sku海报
        List<SkuPoster> skuPosterList = skuInfoVo.getSkuPosterList();
        if (!CollectionUtils.isEmpty(skuPosterList)){
            int sort = 1;
            for (SkuPoster skuPoster:skuPosterList){
                skuPoster.setSkuId(id);
                sort++;
            }
            skuPosterService.saveBatch(skuPosterList);
        }

        // 删除sku图片
        skuImageService.remove(new LambdaQueryWrapper<SkuImage>().eq(SkuImage::getSkuId,id));

        // 保存sku图片
        List<SkuImage> skuImageList = skuInfoVo.getSkuImagesList();
        if (!CollectionUtils.isEmpty(skuImageList)){
            int sort = 1;
            for (SkuImage skuImage:skuImageList){
                skuImage.setSkuId(id);
                skuImage.setSort(sort);
                sort++;
            }
            skuImageService.saveBatch(skuImageList);
        }

        // 删除sku平台属性
        skuAttrValueService.remove(new LambdaQueryWrapper<SkuAttrValue>().eq(SkuAttrValue::getAttrId,id));
        // 保存sku平台属性
        List<SkuAttrValue> skuAttrValueList = skuInfoVo.getSkuAttrValueList();
        if (!CollectionUtils.isEmpty(skuAttrValueList)){
            int sort = 1;
            for (SkuAttrValue attrValue:skuAttrValueList){
                attrValue.setAttrId(id);
                attrValue.setSort(sort);
                sort++;
            }
            skuAttrValueService.saveBatch(skuAttrValueList);
        }
    }

    /**
     * 商品审核
     * @param id
     * @param status
     */
    @Transactional(rollbackFor = {Exception.class})
    @Override
    public void check(Long id, Integer status) {
        /**
         * 更新发布状态
         */
        SkuInfo skuInfo = new SkuInfo();
        skuInfo.setId(id);
        skuInfo.setCheckStatus(status);
        baseMapper.updateById(skuInfo);
    }

    /**
     * 商品上架
     * @param id
     * @param status
     */
    @Override
    public void publish(Long id, Integer status) {
        // 更改发布状态
        if (status == 1){
            SkuInfo skuInfo = new SkuInfo();
            skuInfo.setId(id);
            skuInfo.setPublishStatus(1);
            baseMapper.updateById(skuInfo);

            // 商品上架：发送mq消息同步es
            rabbitService.sendMessage(MqConst.EXCHANGE_GOODS_DIRECT,
                    MqConst.ROUTING_GOODS_UPPER,id);
        }else {
            SkuInfo skuInfo = new SkuInfo();
            skuInfo.setId(id);
            skuInfo.setPublishStatus(0);
            baseMapper.updateById(skuInfo);

            // 商品下架：发送mq消息同步es
            rabbitService.sendMessage(MqConst.EXCHANGE_GOODS_DIRECT,
                    MqConst.ROUTING_GOODS_LOWER,id);
        }

    }

    /**
     * 新人专享
     * @param id
     * @param status
     */
    @Override
    public void isNewPerson(Long id, Integer status) {
//        SkuInfo skuInfo = new SkuInfo();
//        skuInfo.setId(id);
//        skuInfo.setIsNewPerson(status);
//        baseMapper.updateById(skuInfo);
        if (status == 1){
            SkuInfo skuInfo = new SkuInfo();
            skuInfo.setId(id);
            skuInfo.setIsNewPerson(1);
            baseMapper.updateById(skuInfo);
        }else {
            SkuInfo skuInfo = new SkuInfo();
            skuInfo.setId(id);
            skuInfo.setIsNewPerson(0);
            baseMapper.updateById(skuInfo);
        }
    }


    /**
     * 添加商品
     * @param skuInfoVo
     */
    @Transactional(rollbackFor = {Exception.class})
    @Override
    public void saveBySkuInfo(SkuInfoVo skuInfoVo) {
        // 保存sku信息
        SkuInfo skuInfo = new SkuInfo();
        BeanUtils.copyProperties(skuInfoVo,skuInfo);
        this.save(skuInfo);

        // 保存sku海报
        List<SkuPoster> skuPosterList = skuInfoVo.getSkuPosterList();
        if (!CollectionUtils.isEmpty(skuPosterList)){
            int sort = 1;
            for (SkuPoster skuPoster : skuPosterList){
                skuPoster.setSkuId(skuInfo.getId());
                sort++;
            }
            skuPosterService.saveBatch(skuPosterList);
        }

        // 保存sku图片
        List<SkuImage> skuImagesList = skuInfoVo.getSkuImagesList();
        if (!CollectionUtils.isEmpty(skuImagesList)){
            int sort = 1;
            for (SkuImage skuImage : skuImagesList){
                skuImage.setSkuId(skuInfoVo.getId());
                skuImage.setSort(sort);
                sort ++;
            }
            skuImageService.saveBatch(skuImagesList);
        }

        // 保存sku平台属性
        List<SkuAttrValue> skuAttrValueList = skuInfoVo.getSkuAttrValueList();
        if (!CollectionUtils.isEmpty(skuAttrValueList)){
            int sort = 1;
            for (SkuAttrValue skuAttrValue : skuAttrValueList){
                skuAttrValue.setSkuId(skuInfoVo.getId());
                skuAttrValue.setSort(sort);
                sort ++;
            }
            skuAttrValueService.saveBatch(skuAttrValueList);
        }
    }

    /**
     *批量获取sku信息
     * @param skuInfoList
     * @return
     */
    @Override
    public List<SkuInfo> findSkuInfoList(List<Long> skuInfoList) {
        return this.listByIds(skuInfoList);
    }

    /**
     * 根据关键字获取sku信息
     * @param keyword
     * @return
     */
    @Override
    public List<SkuInfo> skuInfoList(String keyword) {
        LambdaQueryWrapper<SkuInfo> wrapper = new LambdaQueryWrapper<>();
        wrapper.like(SkuInfo::getSkuName,keyword);
        return baseMapper.selectList(wrapper);
    }

}
