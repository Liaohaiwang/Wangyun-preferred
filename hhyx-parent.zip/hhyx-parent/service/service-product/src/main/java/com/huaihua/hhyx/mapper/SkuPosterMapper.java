package com.huaihua.hhyx.mapper;

import com.huaihua.hhyx.model.product.SkuPoster;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 商品海报表 Mapper 接口
 * </p>
 *
 * @author snow
 * @since 2023-08-01
 */
public interface SkuPosterMapper extends BaseMapper<SkuPoster> {

}
