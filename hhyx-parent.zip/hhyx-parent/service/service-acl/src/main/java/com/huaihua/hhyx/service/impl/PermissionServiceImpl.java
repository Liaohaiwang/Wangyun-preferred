package com.huaihua.hhyx.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.huaihua.hhyx.mapper.PermissionMapper;
import com.huaihua.hhyx.model.acl.Permission;
import com.huaihua.hhyx.model.acl.RolePermission;
import com.huaihua.hhyx.service.PermissionService;
import com.huaihua.hhyx.service.RolePermissionService;
import com.huaihua.hhyx.utils.PermissionHelper;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PermissionServiceImpl extends ServiceImpl<PermissionMapper, Permission> implements PermissionService {

    @Resource
    private RolePermissionService rolePermissionService;

    @Resource
    private PermissionService permissionService;

    @Override
    public List<Permission> selectPermissionList() {
        List<Permission> list = permissionService.list();
        List<Permission> permissions = PermissionHelper.buildPermission(list);
        return permissions;
    }

    /**
     * 角色授权
     * @param roleId
     * @param permissionIdList
     */
    @Override
    public boolean doAssign(Long roleId, List<Long> permissionIdList) {
        // 根据角色id删除之前有关的所有记录
        LambdaQueryWrapper<RolePermission> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(RolePermission::getRoleId,roleId);
        rolePermissionService.remove(wrapper);

        // 重新新增有关的权限记录
        RolePermission rolePermission = new RolePermission();
        List<RolePermission> permissionList = new ArrayList<>();
        for (Long permissionId: permissionIdList) {
            rolePermission = new RolePermission();
            rolePermission.setRoleId(roleId);
            rolePermission.setPermissionId(permissionId);
            permissionList.add(rolePermission);
        }
        boolean b = rolePermissionService.saveBatch(permissionList);
        return b;
    }

    /**
     * 根据id获取对应的权限
     * @param roleId
     * @return
     */
    @Override
    public List<Permission> getPermissionListByRoleId(Long roleId) {
        //1.根据roleId获取对应的权限列表
        LambdaQueryWrapper<RolePermission> wrapper = new LambdaQueryWrapper<>();
        //2.非空判断
        if (!StringUtils.isEmpty(roleId)){
            wrapper.eq(RolePermission::getRoleId,roleId);
        }
        //3.查询出所有的角色权限列表
        List<RolePermission> rolePermissions =rolePermissionService.list(wrapper);
        //4.获取角色id对应的所有的权限id
        List<Long> collect = rolePermissions.stream().map(RolePermission::getPermissionId).collect(Collectors.toList());
        //5.根据权限id查询出所有和roleId对应的权限列表 被选中的权限列表
        List<Permission> permissions = new ArrayList<>();
        //6.新建的角色还没有来得及分配权限,根据角色查权限,角色权限表是查不出数据的.数据库角色id对应的信息不能为null.会出现异常.
        if (!CollectionUtils.isEmpty(collect)){
            permissions =permissionService.listByIds(collect);
        }
        //让被选中的权限进行勾选
        //6.让被选中的权限进行勾选
        //6.1 无条件查询出所有的权限列表
        List<Permission> list = permissionService.list();
        //6.2 遍历查出来的所有的权限列表和之前选中的权限列表进行匹配,若匹配,则遍历PermissionList,并将Permission对象中的is_selected设置为true
        for (Permission permission:list) {
            if (permissions.contains(permission)){
                permission.setSelect(true);
                //前端有一个判断是select==true&level==4.
                //level的设置 级别 等级
                // permission.setLevel(4);
            }
        }
        // pid
        // 当前id
        // 查询当前权限的id是否属于某个权限的父id
        // 如果能查询出来，证明当前权限具有子权限
        List<Permission> permissions1 = PermissionHelper.buildPermission(list);
        return permissions1;
    }

    /**
     * 递归删除菜单
     * @param id
     * @return
     */
    @Override
    public boolean removeChildById(Long id) {
        List<Long> longList = new ArrayList<>();
        this.selectChildListById(id,longList);
        longList.add(id);
        baseMapper.deleteBatchIds(longList);
        return true;
    }

    /**
     * 递归获取子节点
     */
    private void selectChildListById(Long id,List<Long> idList){
        List<Permission> permissions = baseMapper.selectList(new QueryWrapper<Permission>().eq("pid",id).select("id"));
        permissions.stream().forEach(item -> {
            idList.add(item.getId());
            this.selectChildListById(item.getId(),idList);
        });
    }
}
