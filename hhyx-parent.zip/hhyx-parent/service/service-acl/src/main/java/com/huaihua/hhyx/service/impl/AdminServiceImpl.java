package com.huaihua.hhyx.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.huaihua.hhyx.mapper.AdminMapper;
import com.huaihua.hhyx.model.acl.Admin;
import com.huaihua.hhyx.model.acl.AdminRole;
import com.huaihua.hhyx.model.acl.Role;
import com.huaihua.hhyx.service.AdminRoleService;
import com.huaihua.hhyx.service.AdminService;
import com.huaihua.hhyx.service.RoleService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AdminServiceImpl extends ServiceImpl<AdminMapper, Admin> implements AdminService {

    @Resource
    private AdminRoleService adminRoleService;

    @Resource
    private RoleService roleService;
    /**
     * 给adminid对应的用户进行角色的授权
     */
    @Override
    public List<Role> assignRoles(Long adminId, String roleIds) {
        // 1.查询出adminId对应的已授权的角色信息
        List<Role> roleList = getRolesByAdminId(adminId);
        // 2.查询出所有角色信息
        List<Role> allRoleList = roleService.list();
        // 将之前该用户所有选中的角色删除(其实是删除admin_role中对应表记录)
        // 3.删除adminId对应的之前的旧的授权信息
        adminRoleService.remove(adminId);
        // 4. 保存新的adminId新勾选的角色信息
        // 以','为标志对字符串进行分割
        // 将roleIds转为List<Long> roleIdList
        String[] strRoleIdArray = roleIds.split(",");
        List<Long> roleIdList = new ArrayList<>();
        for (String strRoleId:strRoleIdArray) {
            roleIdList.add(Long.valueOf(strRoleId));
        }

        // adminRoleService
        // 如何修改用户对应的角色信息
        // 然后将当前勾选的角色对应的数据保存到admin_role表中
        adminRoleService.saveBatch(adminId,roleIdList);

        return null;
    }

    @Override
    public List<Role> getRolesByAdminId(Long adminId) {
        // 根据adminId如何获取这个用户对应的所有角色呢?
        // 根据adminId查询出admin_role表中的所有role_id的集合
        List<AdminRole> adminRoleList = adminRoleService.findAdminRoleList(adminId);
        // 根据role_id的集合查询出所有的List<ROle> roleList
        // 2.1 要获取adminRoleList中的所有role_id，封装成List<Long> idList
        List<Long> roleIdList = new ArrayList<>();
        // 2.2 给adminRoleList去掉重复的记录
        adminRoleList = adminRoleList.stream().distinct().collect(Collectors.toList());
        roleIdList = adminRoleList.stream().map(AdminRole::getRoleId).collect(Collectors.toList());

        List<Role> roleList = new ArrayList<>();
        if (roleIdList.size()>0){
            roleList = roleService.listByIds(roleIdList);
        }
        return roleList;
    }
}
