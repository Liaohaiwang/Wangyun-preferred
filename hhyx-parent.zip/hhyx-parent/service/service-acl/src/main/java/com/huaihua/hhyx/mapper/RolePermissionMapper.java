package com.huaihua.hhyx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.huaihua.hhyx.model.acl.RolePermission;

public interface RolePermissionMapper extends BaseMapper<RolePermission> {
}
