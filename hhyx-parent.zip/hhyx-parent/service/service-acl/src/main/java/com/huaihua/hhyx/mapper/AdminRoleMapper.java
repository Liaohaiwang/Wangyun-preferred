package com.huaihua.hhyx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.huaihua.hhyx.model.acl.AdminRole;

public interface AdminRoleMapper extends BaseMapper<AdminRole> {
}
