package com.huaihua.hhyx.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.huaihua.hhyx.common.result.Result;
import com.huaihua.hhyx.model.acl.Role;
import com.huaihua.hhyx.service.RoleService;
import com.huaihua.hhyx.vo.acl.RoleQueryVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@Slf4j
@RestController
@Api(tags = "角色管理")
@RequestMapping("/admin/acl/role")
//@CrossOrigin    // 跨域
public class RoleController {

    @Resource
    private RoleService roleService;

    /**
     * 角色带分页管理
     */
    @GetMapping("/{page}/{limit}")
    public Result getPageList(@PathVariable Long page,
                              @PathVariable Long limit,
                              RoleQueryVo roleQueryVo){
        log.info("page{},limit{},roleQueryVo{},",page,limit,roleQueryVo);
//        // 分页条件查询
//        // 定义分页的当前页和每页记录数
//        IPage<Role> roleIPage = new Page<>(page,limit);
//        // 定义分页的条件
//        QueryWrapper<Role> wrapper = new QueryWrapper<>();
//        if (!StringUtils.isEmpty(roleQueryVo.getRoleName())){
//            wrapper.like("username",roleQueryVo.getRoleName());
//            System.out.println("username"+roleQueryVo.getRoleName());
//        }
//
//        // 调用adminService来执行分页查询(底层是mybatisplus会根据我们分页条件执行相应的sql语句)
//        IPage<Role> adminIPage1 = roleService.page(roleIPage,wrapper);
//        return Result.ok(adminIPage1);
        Page<Role> page1 = new Page<>(page,limit);
        IPage<Role> roleIPage = roleService.selectPage(page1, roleQueryVo);
        return Result.ok(roleIPage);
    }

    /**
     * 新增角色
     * @param role
     * @return
     */
    @ApiOperation("新增角色")
    @PostMapping("/save")
    public Result save(@RequestBody(required = true) Role role){
        log.info("role{},",role);
        boolean flag = roleService.save(role);
        if (flag){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }

    /**
     * 获取某一个角色
     * @param id
     * @return
     */
    @ApiOperation("获取某一个角色")
    @GetMapping("/get/{id}")
    public Result getById(@PathVariable("id") Long id){
        log.info("id{},",id);
        Role byId = roleService.getById(id);
        return Result.ok(byId);
    }

    /**
     * 更新角色
     * @param role
     * @return
     */
    @ApiOperation("更新角色")
    @PutMapping("/update")
    public Result updateById(@RequestBody Role role){
        log.info("role{},",role);
        boolean flag = roleService.updateById(role);
        if (flag){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }

    /**
     * 获取一个角色的所有权限列表
     */
    @ApiOperation("获取一个角色的所有权限列表")
    @GetMapping("/toAssign/{roleId}")
    public Result getAssign(@PathVariable("roleId") Long roleId){
        return null;
    }

    /**
     * 根据id删除角色
     * @param id
     * @return
     */
    @ApiOperation("根据id删除角色")
    @DeleteMapping("/remove/{id}")
    public Result removeById(@PathVariable("id") Long id){
        boolean flag = roleService.removeById(id);
        if (flag){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }

    /**
     * 根据id批量删除角色
     * @param ids
     * @return
     */
    @ApiOperation("根据id批量删除角色")
    @DeleteMapping("/batchRemove")
    public Result removeRoles(@PathVariable("ids") List<Long> ids){
        log.info("ids{},",ids);
        boolean flag = roleService.removeByIds(ids);
        if (flag){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }
}
