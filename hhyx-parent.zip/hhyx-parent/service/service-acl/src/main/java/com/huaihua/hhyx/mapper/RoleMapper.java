package com.huaihua.hhyx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.huaihua.hhyx.model.acl.Role;
import org.springframework.stereotype.Repository;

@Repository
public interface RoleMapper extends BaseMapper<Role> {
}
