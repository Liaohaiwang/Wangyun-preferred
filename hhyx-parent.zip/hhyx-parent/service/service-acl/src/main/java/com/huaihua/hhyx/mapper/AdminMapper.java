package com.huaihua.hhyx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.huaihua.hhyx.model.acl.Admin;

public interface AdminMapper extends BaseMapper<Admin> {
}
