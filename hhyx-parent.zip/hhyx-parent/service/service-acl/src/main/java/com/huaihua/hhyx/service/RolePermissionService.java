package com.huaihua.hhyx.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.huaihua.hhyx.model.acl.RolePermission;

public interface RolePermissionService extends IService<RolePermission> {
}
