package com.huaihua.hhyx.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.huaihua.hhyx.model.acl.Permission;

import java.util.List;

public interface PermissionService extends IService<Permission> {

    List<Permission> selectPermissionList();

    boolean doAssign(Long roleId, List<Long> permissionIdList);

    List<Permission> getPermissionListByRoleId(Long roleId);

    boolean removeChildById(Long id);
}
