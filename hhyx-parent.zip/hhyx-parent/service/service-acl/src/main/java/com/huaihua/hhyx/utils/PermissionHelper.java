package com.huaihua.hhyx.utils;

import com.huaihua.hhyx.model.acl.Permission;

import java.util.ArrayList;
import java.util.List;

public class PermissionHelper {
    /**
     *帮我们把数据整理成前端所需要的结构
     * @param allPermissionList
     * @return
     */
    public static List<Permission> buildPermission(List<Permission> allPermissionList) {
        //返回什么,定义什么
        List<Permission> trees = new ArrayList<>();
        //遍历权限集合,给每一个权限设置level
        for (Permission permission : allPermissionList) {
            if (permission.getPid() == 0) {
                permission.setLevel(1);
                trees.add(findChildren(permission, allPermissionList));
            }
        }
        return trees;
    }

    private static Permission findChildren(Permission permission, List<Permission> allPermissionList) {
        //permission.第一次进来,是父,不希望permission.gerChildren()是空,否则后面会报空指针异常.
        permission.setChildren(new ArrayList<Permission>());
        for (Permission perm : allPermissionList) {
            if (permission.getId().longValue() == perm.getPid().longValue()) {
                perm.setLevel(permission.getLevel() + 1);
                if (permission.getChildren() == null) {
                    permission.setChildren(new ArrayList<>());
                }
                //封装下一层数据
                permission.getChildren().add(findChildren(perm, allPermissionList));
            }
        }
        return permission;
    }
}
