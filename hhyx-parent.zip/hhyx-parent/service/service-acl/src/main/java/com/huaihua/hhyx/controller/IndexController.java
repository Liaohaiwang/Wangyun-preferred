package com.huaihua.hhyx.controller;

import com.huaihua.hhyx.common.result.Result;
import com.huaihua.hhyx.model.acl.Admin;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Api(tags = "用户访问控制")
@RequestMapping("/admin/acl/index")
@RestController
//@CrossOrigin    // 跨域 可以使客户端从不同的网站来访问该应用程序的资源
public class IndexController {

    /**
     * @ApiOperation 用于描述API接口的操作，包括接口名称、接口描述、请求方法等信息。
     * 该注解可以用在Controller类或Controller方法上。
     *
     * @ApiImplicitParam 用于描述API接口中的参数，包括参数名称、参数类型、是否必填等信息。
     * 该注解可以用在Controller方法的参数上。
     * @param admin
     * @return
     */
    @ApiOperation(value = "login",tags = "登录")
    @ApiImplicitParam(name = "admin",value = "admin")
    @PostMapping("/login")
    public Result login(@RequestBody Admin admin){
        System.out.println("admin:"+admin);
        // 假如登录成功
        Map<String,Object> map = new HashMap<>();
        // token 令牌,通证
        map.put("token","admin-token");
        return Result.ok(map);
    }

    @ApiOperation("获取用户信息")
    @GetMapping("/info")
    public Result info(){
        Map<String,Object> map = new HashMap<>();
        map.put("name","admin");
        map.put("avatar","https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif");
        System.out.println("info map:"+map);
        return Result.ok(map);
    }

    @ApiOperation(value = "logout",tags = "登出")
    @PostMapping("/logout")
    public Result out(){
        System.out.println("登出");
        System.out.println("清除session之类的操作");
        return Result.ok(null);
    }
}
