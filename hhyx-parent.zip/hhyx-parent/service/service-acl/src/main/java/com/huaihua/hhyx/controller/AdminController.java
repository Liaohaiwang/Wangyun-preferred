package com.huaihua.hhyx.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.huaihua.hhyx.common.result.Result;
import com.huaihua.hhyx.common.utils.MD5;
import com.huaihua.hhyx.model.acl.Admin;
import com.huaihua.hhyx.model.acl.Role;
import com.huaihua.hhyx.service.AdminRoleService;
import com.huaihua.hhyx.service.AdminService;
import com.huaihua.hhyx.service.RoleService;
import com.huaihua.hhyx.vo.acl.AdminQueryVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;

@Slf4j
@Api(tags = "用户管理")
@RestController
@RequestMapping("admin/acl/user")
//@CrossOrigin    //跨域
public class AdminController {

    @Resource
    private AdminService adminService;

    @Resource
    private AdminRoleService adminRoleService;

    @Resource
    private RoleService roleService;

    /**
     * 给某个用户分配角色
     */
    @PostMapping("/doAssign")
    public Result assignRoles(@RequestParam("adminId") Long adminId,
                              @RequestParam("roleId") String roleIds){
        // 打印日志记录获取到的值
        log.info("adminId:{}, roleIds:{}",adminId,roleIds);
        List<Role> roleList = adminService.assignRoles(adminId,roleIds);
        return Result.ok(null);
    }

    /**
     * 获取某个用户的角色
     * @return
     */
    @ApiOperation("获取某个用户的角色")
    @GetMapping("/toAssign/{adminId}")
    public Result getRole(@PathVariable("adminId") Long adminId){
        List<Role> roleList = adminService.getRolesByAdminId(adminId);
        // allRolesList,assignRoles
        HashMap<String,Object> map = new HashMap<>();
        map.put("assignRoles",roleList);

        List<Role> allRoleList = roleService.list();
        map.put("allRolesList",allRoleList);
        return Result.ok(map);
    }

    /**
     * 批量删除多个用户
     * @param ids
     * @return
     */
    @ApiOperation("批量删除多个用户")
    @DeleteMapping("/batchRemove")
    public Result removeUsers(@RequestBody List<Long> ids){
        log.info("ids{},",ids);
        boolean flag = adminService.removeByIds(ids);
        if (flag){
            Result.ok(null);
        }
            return Result.ok(null);
    }

    /**
     * 根据id获取某个后台用户
     * @return
     */
    @GetMapping("/get/{id}")
    public Result getById(@PathVariable("id") Long id){
        log.info("id{},",id);
        Admin admin = adminService.getById(id);
        return Result.ok(admin);
    }


    // 带分页查询
    @GetMapping("/{page}/{limit}")
    public Result getPageList(@PathVariable Long page,
                              @PathVariable Long limit,
                              AdminQueryVo adminQueryVo){

        // 分页条件查询
        // 定义分页的当前页和每页记录数
        IPage<Admin> adminIPage = new Page<>(page,limit);
        // 定义分页的条件
        QueryWrapper<Admin> wrapper = new QueryWrapper<>();
        if (!StringUtils.isEmpty(adminQueryVo.getUsername())){
            wrapper.like("username",adminQueryVo.getUsername());
            System.out.println("username"+adminQueryVo.getUsername());
        }

        if (!StringUtils.isEmpty(adminQueryVo.getName())){
            wrapper.like("name",adminQueryVo.getName());
        }
        // 调用adminService来执行分页查询(底层是mybatisplus会根据我们分页条件执行相应的sql语句)
        IPage<Admin> adminIPage1 = adminService.page(adminIPage,wrapper);
        return Result.ok(adminIPage1);
    }

    @ApiOperation(value = "保存一个新的后台用户")
    @PostMapping("/save")
    public Result add(@RequestBody(required = true) Admin admin){
        System.out.println("save admin:"+admin);
        boolean flag = adminService.save(admin);
        // 对admin进行加密处理
        String password = admin.getPassword();
        String encrypt = MD5.encrypt(password);
        admin.setPassword(encrypt);
//        // 也可以使用hutool工具自带的MD5算法
//        admin.setPassword(encrypt);
//        SecureUtil.md5(password);

        if (flag){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }

    @ApiOperation(value = "根据id删除用户")
    @DeleteMapping("remove//{id}")
    public Result delete(@PathVariable Long id){
        boolean flag = adminService.removeById(id);
        if (flag){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }

    @ApiOperation(value = "根据id进行更新用户")
    @PutMapping("/update")
    public Result update(@RequestBody Admin admin){
        boolean b = adminService.updateById(admin);
        if (b){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }
}
