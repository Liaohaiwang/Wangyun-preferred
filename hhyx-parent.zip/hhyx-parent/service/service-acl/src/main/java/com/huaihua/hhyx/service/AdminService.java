package com.huaihua.hhyx.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.huaihua.hhyx.model.acl.Admin;
import com.huaihua.hhyx.model.acl.Role;

import java.util.List;

public interface AdminService extends IService<Admin> {

    /**
     * 给adminid对应的用户进行角色的授权
     */
    List<Role> assignRoles(Long adminId,String roleIds);

    List<Role> getRolesByAdminId(Long adminId);
}
