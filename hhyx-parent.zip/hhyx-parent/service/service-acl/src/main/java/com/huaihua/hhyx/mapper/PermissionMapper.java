package com.huaihua.hhyx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.huaihua.hhyx.model.acl.Permission;

public interface PermissionMapper extends BaseMapper<Permission> {
}
