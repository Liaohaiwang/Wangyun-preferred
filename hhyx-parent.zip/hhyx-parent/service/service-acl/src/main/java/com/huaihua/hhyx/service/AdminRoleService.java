package com.huaihua.hhyx.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.huaihua.hhyx.model.acl.AdminRole;

import java.util.List;

public interface AdminRoleService extends IService<AdminRole>{

    /**
     * 根据adminId查询出admin_role表中的所有role_id的集合
     */
    List<AdminRole> findAdminRoleList(Long adminId);

    /**
     * 根据adminId删除角色授权信息
     */
    void remove(Long adminId);

    /**
     * 批量保存adminId对应的roleId
     */
    void saveBatch(Long adminId,List<Long> roleId);
}
