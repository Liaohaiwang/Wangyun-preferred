package com.huaihua.hhyx.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.huaihua.hhyx.mapper.AdminRoleMapper;
import com.huaihua.hhyx.model.acl.AdminRole;
import com.huaihua.hhyx.service.AdminRoleService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AdminRoleServiceImpl extends ServiceImpl<AdminRoleMapper, AdminRole> implements AdminRoleService {

    /**
     * 根据adminId查询出admin_role表中的所有role_id的集合
     */
    @Override
    public List<AdminRole> findAdminRoleList(Long adminId) {
        LambdaQueryWrapper<AdminRole> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(AdminRole::getAdminId,adminId);
        List<AdminRole> adminRoles = baseMapper.selectList(wrapper);
        return adminRoles;
    }

    /**
     * 根据adminId删除角色授权信息
     */
    @Override
    public void remove(Long adminId) {
        LambdaQueryWrapper<AdminRole> wrapper = new LambdaQueryWrapper<>();
        baseMapper.delete(wrapper);
    }

    /**
     * 批量保存adminId对应的roleId
     */
    @Override
    public void saveBatch(Long adminId, List<Long> roleId) {
        List<AdminRole> adminRoles = new ArrayList<>();
        for (Long roleList:roleId) {
            AdminRole adminRole = new AdminRole();
            adminRole.setAdminId(adminId);
            adminRole.setRoleId(roleList);
            adminRoles.add(adminRole);
        }
        this.saveBatch(adminRoles);
    }
}
