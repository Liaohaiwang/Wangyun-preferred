package com.huaihua.hhyx.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.huaihua.hhyx.mapper.RolePermissionMapper;
import com.huaihua.hhyx.model.acl.RolePermission;
import com.huaihua.hhyx.service.RolePermissionService;
import org.springframework.stereotype.Service;

@Service
public class RolePermissionServiceImpl extends ServiceImpl<RolePermissionMapper, RolePermission> implements RolePermissionService {
}
