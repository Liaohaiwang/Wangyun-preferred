package com.huaihua.hhyx.controller;

import com.huaihua.hhyx.common.result.Result;
import com.huaihua.hhyx.model.acl.Permission;
import com.huaihua.hhyx.service.PermissionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@Api(tags = "菜单管理")
@Slf4j
@RestController
@RequestMapping("/admin/acl/permission")
//@CrossOrigin
public class PermissionController {

    @Resource
    private PermissionService permissionService;

    /**
     * 获取权限列表
     * */
    @ApiOperation("获取权限列表")
    @GetMapping
    public Result getPermissionList(Permission permission){
        log.info("permission{},",permission);
        List<Permission> list = permissionService.selectPermissionList();
        return Result.ok(list);
    }

    /**
    删除一个权限项
    **/
    @ApiOperation("删除")
    @DeleteMapping("/remove/{id}")
    public Result removePermission(@PathVariable("id") Long id){
        log.info("id{},",id);
        // 递归删除菜单
        boolean b = permissionService.removeChildById(id);
        return Result.ok(null);
    }

    /**
    保存一个权限项
    **/
    @ApiOperation("新增")
    @PostMapping("/save")
    public Result addPermission(@RequestBody Permission permission){
        boolean save = permissionService.save(permission);
        if (save){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }

    }

    /**
    更新一个权限项
    **/
    @ApiOperation("更新")
    @PutMapping("/update")
    public Result updatePermission(@RequestBody Permission permission){
        boolean b = permissionService.updateById(permission);
        if (b){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }

    /**
     * 查看某个角色的权限列表
     * */
    @ApiOperation("查看")
    @GetMapping("/toAssign/{roleId}")
    public Result toAssign(@PathVariable("roleId") Long roleId){
        List<Permission> permissionListByRoleId = permissionService.getPermissionListByRoleId(roleId);
        return Result.ok(permissionListByRoleId);
    }

    /**
    给某个角色授权
    **/
    @ApiOperation("给某个角色授权")
    @PostMapping("/doAssign")
    public Result doAssign(@RequestParam("roleId") Long roleId,
                           @RequestParam("permissionId") List<Long> permissionIdList){
        log.info("roleId{},permissionId{},",roleId,permissionIdList);
        boolean b = permissionService.doAssign(roleId, permissionIdList);
        if (b){
            return Result.ok(null);
        }else {
            return Result.fail(null);
        }
    }

}
