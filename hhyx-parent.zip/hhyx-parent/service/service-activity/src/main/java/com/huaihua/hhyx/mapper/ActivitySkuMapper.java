package com.huaihua.hhyx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.huaihua.hhyx.model.activity.ActivitySku;

public interface ActivitySkuMapper extends BaseMapper<ActivitySku> {
}
