package com.huaihua.hhyx.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.huaihua.hhyx.common.result.Result;
import com.huaihua.hhyx.model.activity.CouponInfo;
import com.huaihua.hhyx.service.CouponInfoService;
import com.huaihua.hhyx.vo.activity.CouponRuleVo;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@ApiOperation("优惠券管理")
@RestController
@Slf4j
@RequestMapping("/admin/activity/couponInfo")
//@CrossOrigin
public class CouponInfoController {

    @Resource
    private CouponInfoService couponInfoService;

    @ApiOperation("分页")
    @GetMapping("/{page}/{limit}")
    public Result getPageList(@PathVariable("page") Long page,
                              @PathVariable("limit") Long limit){
        IPage<CouponInfo> pageList = couponInfoService.getPageList(page, limit);
        return Result.ok(pageList);
    }

    @ApiOperation("根据id修改时需要回显数据")
    @GetMapping("/get/{id}")
    public Result getById(@PathVariable("id") Long id){
        CouponInfo byId = couponInfoService.getCouponInfoById(id);
        return Result.ok(byId);
    }

    @ApiOperation("保存")
    @PostMapping("/save")
    public Result save(@RequestBody CouponInfo couponInfo){
        couponInfo.setCreateTime(new Date());
        boolean save = couponInfoService.save(couponInfo);
        if (save){
            return Result.ok();
        }else {
            return Result.fail();
        }
    }

    @ApiOperation("修改")
    @PutMapping("/update")
    public Result updateById(@RequestBody CouponInfo couponInfo){
        boolean b = couponInfoService.updateById(couponInfo);
        if (b){
            return Result.ok();
        }else {
            return Result.fail();
        }
    }

    @ApiOperation("根据id进行删除")
    @DeleteMapping("/remove/{id}")
    public Result removeById(@PathVariable("id") Long id){
        boolean b = couponInfoService.removeById(id);
        if (b){
            return Result.ok();
        }else {
            return Result.fail();
        }
    }

    @ApiOperation("根据id批量删除")
    @DeleteMapping("/batchRemove")
    public Result removeRows(@RequestBody List<Long> ids){
        boolean b = couponInfoService.removeByIds(ids);
        if (b){
            return Result.ok();
        }else {
            return Result.fail();
        }
    }

    @ApiOperation("查找优惠券规则列表")
    @GetMapping("/findCouponRuleList/{id}")
    public Result findCouponRuleList(@PathVariable("id") Long id){
        return Result.ok(couponInfoService.findCouponRuleList(id));
    }

    @ApiOperation("新增优惠券规则")
    @PostMapping("/saveCouponRule")
    public Result saveCouponRule(@RequestBody CouponRuleVo couponRuleVo){
        couponInfoService.saveCouponRule(couponRuleVo);
        return Result.ok();
    }

    @ApiOperation("根据关键字查找优惠券")
    @GetMapping("/findCouponByKeyword/{keyword}")
    public Result findCouponByKeyword(String keyword){
        List<CouponInfo> couponInfoList = couponInfoService.findCouponByKeyword(keyword);
        return Result.ok(couponInfoList);
    }
}
