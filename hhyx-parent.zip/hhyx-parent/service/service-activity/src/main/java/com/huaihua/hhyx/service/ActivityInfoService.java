package com.huaihua.hhyx.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.huaihua.hhyx.model.activity.ActivityInfo;
import com.huaihua.hhyx.model.product.SkuInfo;
import com.huaihua.hhyx.vo.activity.ActivityRuleVo;

import java.util.List;
import java.util.Map;

public interface ActivityInfoService extends IService<ActivityInfo> {
    /**
     * 分页查询
     * @param page1
     */
    IPage<ActivityInfo> selectPage(Page<ActivityInfo> page1);

    /**
     * 查找活动规则列表
     * @param id
     * @return
     */
    Map<String,Object> findActivityRuleList(Long id);

    /**
     * 新增活动规则
     * @param activityRuleVo
     * @return
     */
    void saveActivityRule(ActivityRuleVo activityRuleVo);

    List<SkuInfo> findSkuInfoByKeyword(String keyword);

    IPage<ActivityInfo> getPageList(Long page, Long limit);
}
