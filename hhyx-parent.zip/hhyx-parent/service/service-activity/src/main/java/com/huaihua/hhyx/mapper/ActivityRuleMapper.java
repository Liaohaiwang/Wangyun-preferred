package com.huaihua.hhyx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.huaihua.hhyx.model.activity.ActivityRule;

public interface ActivityRuleMapper extends BaseMapper<ActivityRule> {
}
