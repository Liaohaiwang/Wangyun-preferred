package com.huaihua.hhyx.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.huaihua.hhyx.model.activity.CouponRange;

public interface CouponRangeService extends IService<CouponRange> {
}
