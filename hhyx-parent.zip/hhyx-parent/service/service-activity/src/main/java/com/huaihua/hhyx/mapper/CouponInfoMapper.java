package com.huaihua.hhyx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.huaihua.hhyx.model.activity.CouponInfo;
import org.springframework.stereotype.Component;

@Component
public interface CouponInfoMapper extends BaseMapper<CouponInfo> {
}
