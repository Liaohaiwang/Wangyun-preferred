package com.huaihua.hhyx.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.huaihua.hhyx.client.ProductFeignClient;
import com.huaihua.hhyx.enums.CouponRangeType;
import com.huaihua.hhyx.mapper.CouponInfoMapper;
import com.huaihua.hhyx.mapper.CouponRangeMapper;
import com.huaihua.hhyx.model.activity.CouponInfo;
import com.huaihua.hhyx.model.activity.CouponRange;
import com.huaihua.hhyx.model.product.Category;
import com.huaihua.hhyx.model.product.SkuInfo;
import com.huaihua.hhyx.service.CouponInfoService;
import com.huaihua.hhyx.service.CouponRangeService;
import com.huaihua.hhyx.vo.activity.CouponRuleVo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class CouponInfoServiceImpl extends ServiceImpl<CouponInfoMapper, CouponInfo> implements CouponInfoService {

    @Resource
    private CouponInfoService couponInfoService;

    @Resource
    private CouponInfoMapper couponInfoMapper;

    @Resource
    private CouponRangeService couponRangeService;

    @Resource
    private CouponRangeMapper couponRangeMapper;

    @Resource
    private ProductFeignClient productFeignClient;

    @Override
    public IPage<CouponInfo> getPageList(Long page, Long limit) {
        IPage<CouponInfo> page1 = new Page<>(page,limit);
        IPage<CouponInfo> pageList = couponInfoService.page(page1);
        List<CouponInfo> records = pageList.getRecords();
        for (CouponInfo couponInfo:records) {
            if (couponInfo.getCouponType() != null){
                couponInfo.setCouponTypeString(couponInfo.getCouponType().getComment());
            }
            if (couponInfo.getRangeType() != null){
                couponInfo.setRangeTypeString(couponInfo.getRangeType().getComment());
            }
        }
        pageList.setRecords(records);
        return pageList;
    }

    @Override
    public List<CouponInfo> findCouponByKeyword(String keyword) {
        List<CouponInfo> couponInfoList = baseMapper.selectList(new LambdaQueryWrapper<CouponInfo>().like(CouponInfo::getCouponName, keyword));
        return couponInfoList;
    }

    @Override
    public Map<String,Object> findCouponRuleList(Long id) {
        Map<String,Object> map = new HashMap();
        // 查询优惠券信息
        CouponInfo couponInfo = baseMapper.selectById(id);
        map.put("couponInfo",couponInfo);
        // 查询优惠券规则

        // 查询优惠券范围
        List<CouponRange> couponRangeList = couponRangeService.list(new LambdaQueryWrapper<CouponRange>().eq(CouponRange::getCouponId,id));
        List<Long> collect = couponRangeList.stream().map(CouponRange::getRangeId).collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(collect)){
            // 如果 couponInfo.getRangeType ==CouponRange.Sku     如果优惠券信息的使用范围等于Sku平台
            // 那么collect就代表了Sku
            if (couponInfo.getRangeType() == CouponRangeType.SKU){
                List<SkuInfo> skuInfoList = productFeignClient.findSkuInfoList(collect);
                map.put("skuInfoList",skuInfoList);
            }else if (couponInfo.getRangeType() == CouponRangeType.CATEGORY){
                List<Category> categoryList = productFeignClient.findCategoryList(collect);
                map.put("categoryList",categoryList);
            }
        }
        return map;
    }

    /**
     * 新增优惠券规则
     * @param
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void saveCouponRule(CouponRuleVo couponRuleVo) {
        /**
         * 优惠券couponInfo与couponRange 要一起操作：先删除couponRange，更新couponInfo，
         * 再新增couponRange
         */
        Long couponId = couponRuleVo.getCouponId();
        // 删除couponRange
        couponRangeMapper.delete(new LambdaQueryWrapper<CouponRange>().eq(CouponRange::getCouponId, couponId));

        // 更新couponInfo
        CouponInfo couponInfo = baseMapper.selectById(couponId);
        // 使用范围
        couponInfo.setRangeType(couponRuleVo.getRangeType());
        // 使用门槛
        couponInfo.setConditionAmount(couponRuleVo.getConditionAmount());
        // 范围
        couponInfo.setAmount(couponRuleVo.getAmount());
        // 范围描述
        couponInfo.setRangeDesc(couponRuleVo.getRangeDesc());
        // 时间
        couponInfo.setCreateTime(new Date());

        // 进行修改
        couponInfoMapper.updateById(couponInfo);

        // 插入优惠券的规则 couponRangeList
        List<CouponRange> couponRangeList = couponRuleVo.getCouponRangeList();
        for (CouponRange couponRange:couponRangeList) {
            couponRange.setCouponId(couponRuleVo.getCouponId());
            couponRange.setCreateTime(new Date());
            // 插入数据
            couponRangeMapper.insert(couponRange);
        }
    }

    @Override
    public CouponInfo getCouponInfoById(Long id) {
        CouponInfo couponInfo = baseMapper.selectById(id);
        if (couponInfo.getCouponType() != null){
            couponInfo.setCouponTypeString(couponInfo.getCouponType().getComment());
        }
        if (couponInfo.getRangeType() != null){
            couponInfo.setRangeTypeString(couponInfo.getRangeType().getComment());
        }
        return couponInfo;
    }
}
