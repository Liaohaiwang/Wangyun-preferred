package com.huaihua.hhyx.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.huaihua.hhyx.common.result.Result;
import com.huaihua.hhyx.model.activity.ActivityInfo;
import com.huaihua.hhyx.service.ActivityInfoService;
import com.huaihua.hhyx.vo.activity.ActivityRuleVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Slf4j
@Api(tags = "营销活动信息管理")
@RestController
@RequestMapping("/admin/activity/activityInfo")
//@CrossOrigin(origins = "*")
public class ActivityInfoController {

    @Resource
    private ActivityInfoService activityInfoService;

    @GetMapping("/{page}/{limit}")
    public Result getPageList(@PathVariable("page") Long page,
                              @PathVariable("limit") Long limit){
        log.info("page{},limit{},",page,limit);
        Page<ActivityInfo> page1 = new Page<>(page,limit);
        IPage<ActivityInfo> activityInfoIPage = activityInfoService.selectPage(page1);
        IPage<ActivityInfo> InfoPage = activityInfoService.getPageList(page,limit);
        System.out.println("InfoPage======> "+InfoPage);
        return Result.ok(activityInfoIPage);
    }

    @ApiOperation("获取活动")
    @GetMapping("/get/{id}")
    public Result getById(@PathVariable("id") Long id){
        ActivityInfo byId = activityInfoService.getById(id);
        byId.setActivityTypeString(byId.getActivityType().getComment());
        return Result.ok(byId);
    }

    @ApiOperation("新增")
    @PostMapping("/save")
    public Result save(@RequestBody ActivityInfo activityInfo){
        activityInfo.setCreateTime(new Date());
        boolean save = activityInfoService.save(activityInfo);
        if (save){
            return Result.ok();
        }else {
            return Result.fail();
        }
    }

    @ApiOperation("修改")
    @PutMapping("/update")
    public Result updateById(@RequestBody ActivityInfo activityInfo){
        boolean b = activityInfoService.updateById(activityInfo);
        if (b){
            return Result.ok();
        }else {
            return Result.fail();
        }
    }

    @ApiOperation("根据id进行删除")
    @DeleteMapping("/remove/{id}")
    public Result removeById(@PathVariable("id") Long id){
        boolean b = activityInfoService.removeById(id);
        if (b){
            return Result.ok();
        }else {
            return Result.fail();
        }
    }

    @ApiOperation("根据id进行批量删除")
    @DeleteMapping("/batchRemove")
    public Result removeRows(@RequestBody List<Long> ids){
        boolean b = activityInfoService.removeByIds(ids);
        if (b){
            return Result.ok();
        }else {
            return Result.fail();
        }
    }

    @ApiOperation("查找活动规则列表")
    @GetMapping("/findActivityRuleList/{id}")
    public Result findActivityRuleList(@PathVariable("id") Long id){
        return Result.ok(activityInfoService.findActivityRuleList(id));
    }


    @ApiOperation("新增活动规则")
    @PostMapping("/saveActivityRule")
    public Result saveActivityRule(@RequestBody ActivityRuleVo activityRuleVo){
        activityInfoService.saveActivityRule(activityRuleVo);
        return Result.ok();
    }

    @ApiOperation("根据关键字查找sku信息")
    @GetMapping("/findSkuInfoByKeyword/{keyword}")
    public Result findSkuInfoByKeyword(@PathVariable("keyword") String keyword){
        return Result.ok(activityInfoService.findSkuInfoByKeyword(keyword));
    }
}
