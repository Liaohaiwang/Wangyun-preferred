package com.huaihua.hhyx.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.huaihua.hhyx.model.activity.CouponUse;

public interface CouponUserService extends IService<CouponUse> {
}
