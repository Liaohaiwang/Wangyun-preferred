package com.huaihua.hhyx.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.huaihua.hhyx.mapper.CouponRangeMapper;
import com.huaihua.hhyx.model.activity.CouponRange;
import com.huaihua.hhyx.service.CouponRangeService;
import org.springframework.stereotype.Service;

@Service
public class CouponRangeServiceImpl extends ServiceImpl<CouponRangeMapper, CouponRange> implements CouponRangeService {
}
