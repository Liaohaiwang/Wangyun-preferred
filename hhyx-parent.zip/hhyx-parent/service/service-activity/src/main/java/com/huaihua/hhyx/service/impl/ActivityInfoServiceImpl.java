package com.huaihua.hhyx.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.huaihua.hhyx.client.ProductFeignClient;
import com.huaihua.hhyx.mapper.ActivityInfoMapper;
import com.huaihua.hhyx.mapper.ActivityRuleMapper;
import com.huaihua.hhyx.mapper.ActivitySkuMapper;
import com.huaihua.hhyx.model.activity.ActivityInfo;
import com.huaihua.hhyx.model.activity.ActivityRule;
import com.huaihua.hhyx.model.activity.ActivitySku;
import com.huaihua.hhyx.model.product.SkuInfo;
import com.huaihua.hhyx.service.ActivityInfoService;
import com.huaihua.hhyx.vo.activity.ActivityRuleVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class ActivityInfoServiceImpl extends ServiceImpl<ActivityInfoMapper, ActivityInfo> implements ActivityInfoService {

    @Resource
    private ActivityInfoMapper activityInfoMapper;

    @Resource
    private ActivityRuleMapper activityRuleMapper;

    @Resource
    private ActivitySkuMapper activitySkuMapper;

    @Resource
    private ProductFeignClient productFeignClient;

    /**
     * 优惠活动列表方法
     * @param page1
     * @return
     */
    @Override
    public IPage<ActivityInfo> selectPage(Page<ActivityInfo> page1) {
        // 创建一个名为wrapper的查询对象并封装，并指定该类型泛型为Activity
        QueryWrapper<ActivityInfo> wrapper = new QueryWrapper<>();
        // 根据查询对象的id进行降序排序
        wrapper.orderByDesc("id");

        // 通过这段代码的执行，将会执行一个分页查询操作，将查询结果封装到activityInfoPage中返回
        Page<ActivityInfo> activityInfoPage = activityInfoMapper.selectPage(page1, wrapper);
        // 这段代码就是遍历page1对象的记录，并给每一个记录设置一个ActivityTypeString属性，
        // 这个属性的值是根据记录的ActivityType枚举值(Comment)得到的注释
//        page1.getRecords().stream().forEach(item ->{
//            item.setActivityTypeString(item.getActivityType().getComment());
//            if (item.getActivityType() != null){
//                item.setActivityTypeString(item.getActivityType().getComment());
//            }
//        });
        // 将分页查询值的记录进行封装，然后遍历每一个值，如果值不为空并且值的活动类型不能为空
        List<ActivityInfo> records = activityInfoPage.getRecords();
        for (ActivityInfo activityInfo:records) {
            if (activityInfo != null && activityInfo.getActivityType() != null){
                // 将活动类型属性进行设置。并将活动信息的活动类型赋值给activityInfo
                activityInfo.setActivityTypeString(activityInfo.getActivityType().getComment());
            }
        }
        return activityInfoPage;
    }

    @Override
    public Map<String, Object> findActivityRuleList(Long id) {
//        // 实例化一个map
//        Map<String,Object> map = new HashMap<>();
//        // 创建一个名为wrapper的查询对象并封装,指定该类型范型为ActivityRule
//        LambdaQueryWrapper<ActivityRule> wrapper = new LambdaQueryWrapper<>();
//        // 将查询出来的id值与数据库中的activityId进行比较
//        wrapper.eq(ActivityRule::getActivityId,id);
//        // 将查询出来的值封装成一个List集合里面
//        List<ActivityRule> activityRules = activityRuleMapper.selectList(wrapper);
//        // 通过map进行保存值
//        map.put("activityRules",activityRules);
//
//        // 创建一个名为skuLambdaQueryWrapper的查询对象的封装
//        LambdaQueryWrapper<ActivitySku> skuLambdaQueryWrapper = new LambdaQueryWrapper<>();
//        // 将该wrapper对象的id值与数据库中进行比较
//        skuLambdaQueryWrapper.eq(ActivitySku::getActivityId,id);
//        // 将查询到的值封装到一个List集合里面
//        List<ActivitySku> activitySkus = activitySkuMapper.selectList(skuLambdaQueryWrapper);
//        // 使用stream方法将结合转换为流
//        // 使用map方法将每个ActivitySku映射成它的ActivityId
//        // 使用collect方法将流收集成一个Long类型的集合
//        List<Long> collect = activitySkus.stream().map(ActivitySku::getActivityId).collect(Collectors.toList());
//        // 调用productFeignClient的findSkuInfoList(查询Sku信息列表) ,将结果返回
//        List<SkuInfo> skuInfoList = productFeignClient.findSkuInfoList(collect);
//        // 保存到map里面
//        map.put("skuInfoList",skuInfoList);
        Map<String,Object> map = new HashMap<>();
        // 查询活动基本信息
        ActivityInfo activityInfo = activityInfoMapper.selectById(id);
        map.put("activityInfo",activityInfo);

        // 查询活动列表
        List<ActivityRule> activityRuleList = activityRuleMapper.selectList(new LambdaQueryWrapper<ActivityRule>().eq(ActivityRule::getActivityId, id));
        map.put("activityRuleList",activityRuleList);
        // 查询活动商品 中间表
        List<ActivitySku> activitySkus = activitySkuMapper.selectList(new LambdaQueryWrapper<ActivitySku>().eq(ActivitySku::getActivityId, id));
        List<Long> collect = activitySkus.stream().map(ActivitySku::getSkuId).collect(Collectors.toList());
        List<SkuInfo> skuInfoList = new ArrayList<>();
        if (!CollectionUtils.isEmpty(collect)){
            skuInfoList = productFeignClient.findSkuInfoList(collect);
        }
        map.put("skuInfoList",skuInfoList);
        return map;
    }

    /**
     * 保存活动规则
     * @param activityRuleVo
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void saveActivityRule(ActivityRuleVo activityRuleVo) {
        // 根据id删除掉数据库中指定的值
        activityRuleMapper.delete(new LambdaQueryWrapper<ActivityRule>().eq(ActivityRule::getActivityId,activityRuleVo.getActivityId()));
        activitySkuMapper.delete(new LambdaQueryWrapper<ActivitySku>().eq(ActivitySku::getActivityId,activityRuleVo.getActivityId()));

        // 封装多个属性
        List<ActivityRule> activityRuleList = activityRuleVo.getActivityRuleList();
        List<ActivitySku> activitySkuList = activityRuleVo.getActivitySkuList();
        List<Long> couponIdList = activityRuleVo.getCouponIdList();

        // 从数据库中查找筛选id并将结果赋值为activityInfo
        ActivityInfo activityInfo = activityInfoMapper.selectById(activityRuleVo.getActivityId());

        // 进行遍历并赋值
        for (ActivityRule activityRule:activityRuleList) {
            activityRule.setActivityId(activityRuleVo.getActivityId());
            activityRule.setActivityType(activityInfo.getActivityType());
            // 进行数据保存
            activityRuleMapper.insert(activityRule);
        }

        for (ActivitySku activitySku:activitySkuList) {
            activitySku.setActivityId(activityRuleVo.getActivityId());
            activitySkuMapper.insert(activitySku);
        }
    }

    /**
     * 根据关键字查询sku信息
     * @param keyword
     * @return
     */
    @Override
    public List<SkuInfo> findSkuInfoByKeyword(String keyword) {
        List<SkuInfo> skuInfoList = new ArrayList<>();
        List<SkuInfo> skuInfoByKeyword = productFeignClient.findSkuInfoByKeyword(keyword);

        // 去重复
        List<Long> skuList = skuInfoByKeyword.stream().map(SkuInfo::getId).collect(Collectors.toList());

        // 根据collect集合自己手动写SQL语句去除重复,并将存在的id存入到list里面
        List<Long> skuIdListExist = baseMapper.findSkuIdListExist(skuList);
        // 遍历根据关键字查找到的信息
        for (SkuInfo skuInfo:skuInfoByKeyword){
            // 进行值判断，如果当前信息里面没有包含skuInfoByKeyword的值，就进行新增
            if (!skuIdListExist.contains(skuInfo.getId())){
                skuInfoList.add(skuInfo);
            }
        }
        return skuInfoList;
    }

    @Override
    public IPage<ActivityInfo> getPageList(Long page, Long limit) {
        IPage<ActivityInfo> page1 = new Page<>(page,limit);
        IPage<ActivityInfo> page2 = this.page(page1);
        List<ActivityInfo> records = page2.getRecords();
        for (ActivityInfo activityInfo:records) {
            if (activityInfo != null && activityInfo.getActivityType() != null){
                activityInfo.setActivityTypeString(activityInfo.getActivityType().getComment());
            }
        }
        return page2;
    }
}
