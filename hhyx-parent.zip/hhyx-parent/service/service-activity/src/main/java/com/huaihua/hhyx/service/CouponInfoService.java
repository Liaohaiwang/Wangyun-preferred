package com.huaihua.hhyx.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.huaihua.hhyx.model.activity.CouponInfo;
import com.huaihua.hhyx.vo.activity.CouponRuleVo;

import java.util.List;
import java.util.Map;

public interface CouponInfoService extends IService<CouponInfo> {

    /**
     * 分页
     * @param page
     * @param limit
     * @return
     */
    IPage<CouponInfo> getPageList(Long page, Long limit);

    /**
     * 根据关键字查询优惠券
     * @param keyword
     * @return
     */
    List<CouponInfo> findCouponByKeyword(String keyword);

    Map<String,Object> findCouponRuleList(Long id);

    void saveCouponRule(CouponRuleVo couponRuleVo);

    /**
     * 修改时需要回显
     * @param id
     * @return
     */
    CouponInfo getCouponInfoById(Long id);
}
