package com.huaihua.hhyx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.huaihua.hhyx.model.activity.ActivityInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ActivityInfoMapper extends BaseMapper<ActivityInfo> {

    List<Long> findSkuIdListExist(@Param("skuList") List<Long> skuList);
}
