package com.huaihua.hhyx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.huaihua.hhyx.model.activity.CouponUse;
import org.springframework.stereotype.Component;

@Component
public interface CouponUserMapper extends BaseMapper<CouponUse> {
}
