package com.huaihua.hhyx.common.exception;

import com.huaihua.hhyx.common.result.Result;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class GlobalHhyxExceptionHandler {
    // 自定义异常处理
    @ResponseBody // 以json格式返回
    @ExceptionHandler()
    public Result hhyxExceptionHandler(HhyxException e){
        e.printStackTrace();
        return Result.build(null,e.getCode(),e.getMessage());
    }

    // 所有的Exception异常处理
    @ExceptionHandler
    @ResponseBody
    public Result globalExceptionHandler(Exception e){
        e.printStackTrace();
        return Result.fail(null);
    }
}
