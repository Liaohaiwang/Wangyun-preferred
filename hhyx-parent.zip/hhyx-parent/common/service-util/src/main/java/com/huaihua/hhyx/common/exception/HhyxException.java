package com.huaihua.hhyx.common.exception;

import com.huaihua.hhyx.common.result.ResultCodeEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HhyxException extends RuntimeException{

    private Integer code;
    private String message;

    public HhyxException(String message, Integer code){
        super(message);
        this.code = code;
    }

    public HhyxException(ResultCodeEnum resultCodeEnum){
        super(resultCodeEnum.getMessage());
        this.code= resultCodeEnum.getCode();
    }
}
