package com.huaihua.hhyx.common.result;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Result<T> {
    private Integer code;   // 结果状态码
    private String message; // 结果消息
    private T data;         // 结果中封装的数据

    /**
     * 私有的无参构造，目的不让别的类直接new Result()
     * 避免返回的Result中没有封装code,message信息
     */
    private Result(){}

    public static<T> Result<T> build(T data, Integer code, String message){
        Result result = new Result();
        if (data != null){
            result.setData(data);
        }
        result.setCode(code);
        result.setMessage(message);
        return result;
    }

    public static<T> Result<T> build(T data,ResultCodeEnum resultCodeEnum){
        Result result = new Result();
        if (data != null){
            result.setData(data);
        }
        result.setCode(resultCodeEnum.getCode());
        result.setMessage(resultCodeEnum.getMessage());
        return result;
    }

    public static<T> Result<T> ok(T data){
        return build(data,ResultCodeEnum.SUCCESS);
    }

    public static Result<Void> ok() {
        return build(null, ResultCodeEnum.SUCCESS);
    }

    public static<T> Result<T> fail(T data){
        return build(data,ResultCodeEnum.FAIL);
    }

    public static Result<Void> fail() {
        return build(null, ResultCodeEnum.FAIL);
    }
}
