package com.huaihua.hhyx.common.utils.jwt;

import io.jsonwebtoken.*;
import org.springframework.util.StringUtils;

import java.util.Date;

public class JwtHelper {

    // 定义俩个静态常量，一个令牌过期时间(tokenExpiration),一个令牌签名密钥(tokenSignKey)
    private static long tokenExpiration = 365*24*60*60*1000;
    private static String tokenSignKey = "hhyx";

    // 定义静态方法，创建一个令牌，需要userID和userName
    public static String createToken(long userId,String userName){
        // 使用Jwts开始构建
        String compact = Jwts.builder()
                // 设置主题(setSubject)
                .setSubject("hhyx-USER")
                // 设置过期时间(Expiration)
                .setExpiration(new Date(System.currentTimeMillis() + tokenExpiration))
                // 声称(claim)俩个变量userId和userName
                .claim("userId", userId)
                .claim("userName", userName)
                // 进行数字签名(signWith)
                .signWith(SignatureAlgorithm.ES512, tokenSignKey)
                // 进行压缩(compressWith)
                .compressWith(CompressionCodecs.GZIP)
                // 再进行紧密压缩(compact)
                .compact();
        // 返回
        return compact;
    }

    // 定义获取UserId的方法，把令牌(token)值传入进去
    public static Long getUserId(String token){
        // 进行令牌值的非空判断，如果是空直接return出去null;
        if (StringUtils.isEmpty(token)) return null;

        Jws<Claims> claimsJws = Jwts.parser().setSigningKey(tokenSignKey).parseClaimsJws(token);
        Claims body = claimsJws.getBody();
        Integer userId = (Integer) body.get("userId");
        return userId.longValue();
    }

    // 定义获取userName的方法，把令牌(token) 放进去
    public static String getUserName(String token){
        if (StringUtils.isEmpty(token)) return "";

        Jws<Claims> claimsJws = Jwts.parser().setSigningKey(tokenSignKey).parseClaimsJws(token);
        Claims body = claimsJws.getBody();
        return (String) body.get("userName");
    }

    // 定义删除令牌
    public static void removeToken(String token){

    }

    // 定义主方法
    public static void main(String[] args) {
        String admin = JwtHelper.createToken(7L, "admin");
        System.out.println(admin);
        System.out.println(JwtHelper.getUserId(admin));
        System.out.println(JwtHelper.getUserName(admin));
    }
}
