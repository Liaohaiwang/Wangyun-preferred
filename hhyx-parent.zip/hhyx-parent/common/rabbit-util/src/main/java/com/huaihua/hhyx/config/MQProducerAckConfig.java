package com.huaihua.hhyx.config;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

public class MQProducerAckConfig implements RabbitTemplate.ReturnCallback,RabbitTemplate.ConfirmCallback {

    // 我们发送消息使用的是 private RabbitTemplate rabbitTemplate； 对象
    // 如果不做设置的话，当前的rabbitTemplate 与当前的配置类没有任何关系
    @Resource
    private RabbitTemplate rabbitTemplate;

    // 设置 表示修饰一个非静态的void方法，在服务器加载Servlet的时候运行，并且只执行一次
    @PostConstruct
    public void init(){
        rabbitTemplate.setReturnCallback(this);
        rabbitTemplate.setConfirmCallback(this);
    }

    /**
     * 表示消息是否正确发送到了交换机上
     * @param correlationData   消息的载体
     * @param b     判断是否发送到交换机上
     * @param s     原因
     */
    @Override
    public void confirm(CorrelationData correlationData, boolean b, String s) {
        if (b){
            System.out.println("消息发送成功!");
        }else {
            System.out.println("消息发送失败!"+s);
        }
    }

    /**
     *消息如果没有正确发送到
     * @param message   消息
     * @param replyCode    应答密码
     * @param replyText    回答
     * @param exchange     交换
     * @param routingKey   路由键
     */
    @Override
    public void returnedMessage(Message message, int replyCode, String replyText, String exchange, String routingKey) {
        System.out.println("消息主题：" + new String(message.getBody()));
        System.out.println("应答码: "+replyCode);
        System.out.println("描述: "+replyText);
        System.out.println("消息使用的交换器 exchange: "+exchange);
        System.out.println("消息使用的路由键 routingKey: "+routingKey);
    }
}
