package com.huaihua.hhyx.enums;

import com.alibaba.fastjson.annotation.JSONType;
import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.databind.deser.std.EnumDeserializer;
import com.fasterxml.jackson.databind.ser.std.EnumSerializer;
import io.swagger.models.auth.In;
import lombok.Getter;

@JSONType(serializer = EnumSerializer.class,deserializer = EnumDeserializer.class, serializeEnumAsJavaBean = true)
@Getter
public enum BillType {
    ORDER(0,"订单佣金"),
    WITHDRAW(1,"提现"),
    REFUND(1,"订单退款");

    /**
     * @EnumValue 是 MyBatis-Plus 提供的一个注解，它用于标识枚举类中哪个字段对应数据库表中的列。
     * 在 MyBatis-Plus 中，当我们使用枚举类作为实体类的一个属性时，如果不使用 @EnumValue 注解进行标识，
     * MyBatis-Plus 将无法自动将数据库中的列值映射到对应的枚举值上。
     */
    @EnumValue
    private Integer code;
    private String comment;

    BillType(Integer code, String comment){
        this.code = code;
        this.comment = comment;
    }
}
